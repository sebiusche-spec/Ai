# SHIVAM OS — upgrade notes (v2.0.0)

This document is the honest status of the upgrade. Read it before you rely on any feature.

## Build verification status

**Not verified.** The authoring environment had no Android SDK, no Gradle distribution, no Kotlin
compiler, and no network access. The code was checked by static inspection only (imports, braces,
package/directory match, resource references, and the Room migration SQL by reading). **The project has
not been compiled and no APK has been produced by the author.**

To build it for real, use the GitHub Actions workflow in `.github/workflows/android-debug-apk.yml`
(instructions below). The workflow runs `testDebugUnitTest` and `assembleDebug` on a GitHub runner and
uploads the APK as a build artifact. Expect a few compile fixes on the first run; the logs show them.

## What changed in v2.0.0

### Dashboard (Home)
- Cinematic navy/cyan background drawn with Compose vector shapes (no image assets, no bitmap memory).
- Left navigation panel: Home, Settings, Jarvis, Alarms, Reminders, Notes, Gallery, Tools.
- Greeting "Hey Shivam, kya karna hai?", live clock (updates once per minute, recomputed from the system clock),
  battery and network status (no permission needed beyond ACCESS_NETWORK_STATE).
- Animated AI core that reacts to busy and service-running state.
- Command bar: typed commands run through the same pipeline as voice and chat.
- Shortcuts: Apps, Settings, Gallery, Browser, AI Tools, More. Each opens a real screen or intent.
- Right-side cards: next alarm with countdown, upcoming alarms, quick actions (Open app, Take photo,
  New alarm, New note), system status, recent commands.
- Responsive: a two-column layout at 720dp width or wider, a single scrolling column below that.

### Assistant service
- `AssistantService` is a user-started foreground service with a persistent "Jarvis is active" notification
  and a **Stop assistant** action. Start and Stop are also on the Home screen.
- Type: `specialUse` with a subtype property. It does **not** record audio, so it does not declare the
  microphone foreground-service type.
- It uses `START_NOT_STICKY`. It never restarts itself after a stop, and the system does not restart it
  after a kill either. The user must start it again.
- The service refuses to start without notification permission on Android 13+, so the persistent Stop
  notification is never missing.

### Jarvis commands
New, working: current time ("time kya hua hai"), battery ("battery kitni hai"), open settings
("settings kholo"). Existing: flashlight on/off (asks for confirmation), open app (asks for confirmation),
alarm at a time, notes ("note: …"), remember facts, and the AI fallback.

### Notes
- Create, edit, search (title, text, category), and delete, with a confirmation dialog.
- Categories and last-updated timestamps. Schema v2 keeps existing notes (see migration below).
- Jarvis can still create notes by voice.

### Gallery
- Uses Android's photo picker (`PickMultipleVisualMedia`), so **no storage permission is requested**.
- Stores only the picked content URIs. Removing an item removes it from SHIVAM OS, not from the device.
- Thumbnails are decoded off the main thread with a 1/4 sample size.

### Tools
- Clock, stopwatch (start, pause, reset), battery, and links to the timer, control center, alarm and
  reminder screens, voice test, AI connection test, permissions and diagnostics, and Study Pilot.

### Database
- Schema version 2. `MIGRATION_1_2` adds `notes.category`, `notes.updatedAt`, and the `gallery_items` table.
  Existing notes are kept. The migration is not yet tested on a device.

### Build and CI
- `versionCode 2`, `versionName 2.0.0`.
- GitHub Actions workflow: JDK 17, Android SDK, Gradle 8.9, unit tests, debug APK, artifact upload.
- The workflow calls a system Gradle 8.9, so it does not need the wrapper jar.

## Features NOT implemented in this version (be aware)

- **Reminders engine.** The "Reminders" nav item opens the alarm screen. Alarms and one-time reminders
  share that screen. Recurring custom reminders with categories, priorities, completed states, and
  follow-up notifications are not built.
- **Natural-language scheduling.** "Kal subah 6 baje", "10 minute baad", "har roz shaam 7 baje" are not
  parsed yet. Jarvis can only set a same-day alarm from a time such as "alarm 6:30 am".
- **Background voice listening.** The assistant service does not listen to the microphone. Voice works
  while the app is open. Continuous microphone listening would need a visible microphone foreground
  service and an explicit user action; it is not enabled.
- **Automatic background timers.** Countdown timers run only while the app is open.
- **Alarm tones, vibration choice, full-screen alarm UI, snooze settings, and exact-alarm guidance.**
  The alarm notification has Snooze and Dismiss actions. Tone choice and a full-screen alarm are not built.
- **Calculator** in Tools.
- **Dashboard CPU and RAM rings.** Apps cannot read system-wide CPU and RAM on modern Android. The
  system card shows battery, network, AI and service status instead.
- **Dark/light theme switch, name editor, and export/import** of settings and data.
- **Quick actions "Screen record" and "Dark mode"** from the reference. Apps cannot start system screen
  recording or switch the system dark mode, so those were not added.
- **Weather** and **media player** cards shown in the reference image.
- **Reference photo as wallpaper.** The reference artwork is not included in the project; the background is a
  drawn gradient.

## Features that need configuration or device permission

| Feature | Requirement |
|---|---|
| Typed commands and chat answers | Configure an AI provider in Settings (key entered on the device) |
| Voice input | Microphone permission; Google speech services or a recognizer installed and online |
| Spoken replies | A text-to-speech engine with the language installed |
| Start assistant | Notification permission (Android 13+) so the Stop notification can appear |
| Alarms | Notification permission. Exact timing needs "Alarms & reminders" access (Android 12+) |
| Reboot restore | Automatic; the BOOT_COMPLETED receiver is declared |
| Flashlight | A back camera with a torch; the app asks for confirmation each time |
| Open app | Installed apps only |
| Gallery | Nothing special; uses the system photo picker |
| Battery and network | Nothing special |
| Take photo | A camera app on the device |

## Install the APK from GitHub Actions (on your Android phone)

1. Put this project in a GitHub repository (create one at github.com, then upload the folder or push it with git).
2. Open the repository on GitHub, go to **Actions**, choose **Android debug APK**, then **Run workflow**
   (or push a commit; the workflow also runs on push and pull request).
3. Wait for the run to finish. A green check means the tests and the APK build passed. A red X means open
   the run and read the first error in the log; send it to whoever is fixing the build.
4. Open the finished run, scroll to **Artifacts**, and download `shivam-os-debug-apk` on the phone or a
   computer. The download is a ZIP that contains the `.apk` file. Unzip it.
5. On the phone, open the APK file. Android asks you to allow installing from this source (Settings → Apps →
   Special access → Install unknown apps, for the app you used to open the file). Allow it, then install.
6. Open SHIVAM OS. Allow notifications and microphone when asked. Add your AI key in Settings.

The debug APK is signed with the debug key. It is for testing, not for the Play Store.

## Security notes

- No API key is in the source, the APK, or the workflow. Keys are typed into the app on the device.
- An APK's contents can always be extracted. Do not add secrets to the repository or to `build.gradle`.
- The workflow does not use repository secrets, so it can run on pull requests from forks safely.
