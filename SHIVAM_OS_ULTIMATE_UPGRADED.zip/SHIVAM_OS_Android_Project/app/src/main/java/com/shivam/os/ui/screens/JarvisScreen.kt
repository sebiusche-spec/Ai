package com.shivam.os.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

/** Jarvis hosts the voice assistant and the chat history in one place. */
@Composable
fun JarvisScreen(onOpenSettings: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Voice") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Chat") })
        }
        Box(Modifier.fillMaxWidth().weight(1f)) {
            if (tab == 0) VoiceScreen() else ChatScreen(onOpenSettings = onOpenSettings)
        }
    }
}
