package com.shivam.os.alarm

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.shivam.os.MainActivity
import com.shivam.os.ShivamApp
import com.shivam.os.data.AlarmEntity
import com.shivam.os.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.ZonedDateTime

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {
            try {
                when (intent.action) {
                    ACTION_FIRE -> onFire(
                        context,
                        intent.getIntExtra(EXTRA_ALARM_ID, -1),
                        snoozed = intent.getBooleanExtra(EXTRA_SNOOZED, false)
                    )
                    ACTION_SNOOZE -> {
                        val id = intent.getIntExtra(EXTRA_ALARM_ID, -1)
                        cancelNotification(context, id)
                        AlarmScheduler(context).snooze(id, SNOOZE_MINUTES)
                    }
                    ACTION_DISMISS -> cancelNotification(context, intent.getIntExtra(EXTRA_ALARM_ID, -1))
                }
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun onFire(context: Context, alarmId: Int, snoozed: Boolean) {
        if (alarmId < 0) return
        val dao = AppDatabase.get(context).alarmDao()
        val alarm: AlarmEntity = dao.byId(alarmId) ?: return
        // A one-shot alarm is disabled when it first fires, so a snoozed re-fire must bypass that check.
        if (!alarm.enabled && !snoozed) return

        showNotification(context, alarm)

        val scheduler = AlarmScheduler(context)
        if (alarm.repeatDaysMask == 0) {
            dao.update(alarm.copy(enabled = false))
        } else {
            scheduler.schedule(alarm, ZonedDateTime.now())
        }
    }

    private fun showNotification(context: Context, alarm: AlarmEntity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            return // Permission denied: the alarm still fired in the DB, but nothing can be shown.
        }

        val openApp = PendingIntent.getActivity(
            context, alarm.id, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val snooze = PendingIntent.getBroadcast(
            context, alarm.id + 200_000,
            Intent(context, AlarmReceiver::class.java).setAction(ACTION_SNOOZE).putExtra(EXTRA_ALARM_ID, alarm.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val dismiss = PendingIntent.getBroadcast(
            context, alarm.id + 300_000,
            Intent(context, AlarmReceiver::class.java).setAction(ACTION_DISMISS).putExtra(EXTRA_ALARM_ID, alarm.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        val notification = NotificationCompat.Builder(context, ShivamApp.CHANNEL_ALARMS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(alarm.label.ifBlank { "Alarm" })
            .setContentText(String.format("%02d:%02d", alarm.hour, alarm.minute))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(openApp)
            .addAction(0, "Snooze 10m", snooze)
            .addAction(0, "Dismiss", dismiss)
            .setSound(alarmSound, AudioAttributes.USAGE_ALARM)
            .build()

        NotificationManagerCompat.from(context).notify(notificationId(alarm.id), notification)
    }

    private fun cancelNotification(context: Context, alarmId: Int) {
        if (alarmId < 0) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(notificationId(alarmId))
    }

    companion object {
        const val ACTION_FIRE = "com.shivam.os.action.ALARM_FIRE"
        const val ACTION_SNOOZE = "com.shivam.os.action.ALARM_SNOOZE"
        const val ACTION_DISMISS = "com.shivam.os.action.ALARM_DISMISS"
        const val EXTRA_ALARM_ID = "alarm_id"
        const val EXTRA_SNOOZED = "snoozed"
        const val SNOOZE_MINUTES = 10

        fun notificationId(alarmId: Int) = 4000 + alarmId
    }
}
