package com.shivam.os.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        MessageEntity::class, AlarmEntity::class, NoteEntity::class,
        MemoryEntity::class, RoutineEntity::class, GalleryItemEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun alarmDao(): AlarmDao
    abstract fun noteDao(): NoteDao
    abstract fun memoryDao(): MemoryDao
    abstract fun routineDao(): RoutineDao
    abstract fun galleryDao(): GalleryDao

    /** Privacy: wipes all locally stored user data. */
    suspend fun deleteAllUserData() {
        messageDao().clear()
        alarmDao().clear()
        noteDao().clear()
        memoryDao().clear()
        routineDao().clear()
        galleryDao().clear()
    }

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "shivam_os.db"
            ).addMigrations(MIGRATION_1_2).build().also { instance = it }
        }

        /** Keeps existing notes, adds categories and the gallery table. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE notes ADD COLUMN category TEXT NOT NULL DEFAULT 'General'")
                db.execSQL("ALTER TABLE notes ADD COLUMN updatedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `gallery_items` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`uri` TEXT NOT NULL, " +
                        "`addedAt` INTEGER NOT NULL)"
                )
            }
        }
    }
}
