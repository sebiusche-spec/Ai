package com.shivam.os.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.ai.AiResult
import com.shivam.os.data.NoteEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class StudyMode(val label: String, val instruction: String) {
    EXPLAIN("Explain", "Explain the topic simply, with one worked example and common mistakes."),
    SUMMARIZE("Summarize", "Summarize the text into key points and a 3-line takeaway."),
    QUIZ("Quiz me", "Create 5 practice questions with answers hidden under a 'Answers:' heading at the end."),
    SCHEDULE("Study plan", "Create a day-by-day study schedule for the topic with realistic daily hours.")
}

class StudyViewModel(private val app: ShivamApp) : ViewModel() {

    val notes: StateFlow<List<NoteEntity>> = app.db.noteDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _output = MutableStateFlow("")
    val output: StateFlow<String> = _output.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    fun run(mode: StudyMode, input: String, days: Int = 7) {
        if (input.isBlank() || _busy.value) return
        viewModelScope.launch {
            _busy.value = true
            val system = "You are Study Pilot, a patient tutor in the SHIVAM OS app. Reply in the same language as the " +
                "user's input (English, Hindi, or Hinglish). Use Markdown headings and short lists."
            val prompt = buildString {
                appendLine(mode.instruction)
                if (mode == StudyMode.SCHEDULE) appendLine("Plan length: $days days.")
                appendLine()
                append(input)
            }
            _output.value = when (val r = app.chat.oneShot(system, prompt)) {
                is AiResult.Ok -> r.text
                is AiResult.Error -> "⚠ ${r.message}"
            }
            _busy.value = false
        }
    }

    fun saveOutputAsNote(title: String) {
        val body = _output.value
        if (body.isBlank() || body.startsWith("⚠")) return
        viewModelScope.launch {
            app.db.noteDao().insert(NoteEntity(title = title.ifBlank { "Study note" }.take(60), body = body))
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch { app.db.noteDao().delete(note) }
    }
}
