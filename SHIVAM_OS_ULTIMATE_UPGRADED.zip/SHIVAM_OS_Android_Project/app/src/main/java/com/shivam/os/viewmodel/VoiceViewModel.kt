package com.shivam.os.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.alarm.AlarmTimeCalculator
import com.shivam.os.voice.VoiceListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class VoiceViewModel(private val app: ShivamApp) : ViewModel() {

    private val listener = VoiceListener(app)

    val listening: StateFlow<Boolean> = listener.listening
    val level: StateFlow<Float> = listener.level
    val partial: StateFlow<String> = listener.partial
    val speaking: StateFlow<Boolean> = app.speaker.speaking
    val engineStatus: StateFlow<String> = app.speaker.engineStatus

    private val _heard = MutableStateFlow("")
    val heard: StateFlow<String> = _heard.asStateFlow()

    private val _reply = MutableStateFlow("")
    val reply: StateFlow<String> = _reply.asStateFlow()

    private val _status = MutableStateFlow("Tap the core and speak.")
    val status: StateFlow<String> = _status.asStateFlow()

    init {
        listener.onFinalResult = { text -> handle(text) }
        listener.onErrorMessage = { message -> _status.value = message }
    }

    fun speechAvailable(): Boolean = listener.isAvailable()

    /** Called after the UI has confirmed RECORD_AUDIO. */
    fun startListening() {
        viewModelScope.launch {
            val lang = app.settings.ttsLanguage.first()
            _status.value = "Listening…"
            listener.start(recognizerLanguage(lang))
        }
    }

    fun stopListening() = listener.stop()

    fun onMicPermissionDenied() {
        _status.value = "Microphone permission denied. Enable it in Android Settings to use voice."
    }

    fun submitTyped(text: String) = handle(text)

    /** Interrupt control: stops both microphone capture and spoken output. */
    fun interrupt() {
        listener.stop()
        app.speaker.stop()
        _status.value = "Interrupted."
    }

    fun morningBrief() {
        viewModelScope.launch {
            val now = ZonedDateTime.now()
            val greeting = when (now.hour) {
                in 5..11 -> "Good morning"
                in 12..16 -> "Good afternoon"
                in 17..21 -> "Good evening"
                else -> "Hello"
            }
            val next = app.db.alarmDao().enabled().minByOrNull {
                AlarmTimeCalculator.nextTrigger(now, it.hour, it.minute, it.repeatDaysMask)
            }
            val nextText = next?.let {
                val at = Instant.ofEpochMilli(AlarmTimeCalculator.nextTrigger(now, it.hour, it.minute, it.repeatDaysMask))
                    .atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEEE h:mm a"))
                " Your next alarm, ${it.label}, is on $at."
            }.orEmpty()
            val text = "$greeting. It is ${now.format(DateTimeFormatter.ofPattern("EEEE, MMMM d"))}.$nextText"
            _reply.value = text
            speakWithSettings(text)
        }
    }

    private fun handle(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _heard.value = text
            _status.value = "Thinking…"
            val result = app.assistant.handle(text)
            _reply.value = result.text
            _status.value = if (result.isError) "Something went wrong." else "Done."
            speakWithSettings(result.text)
        }
    }

    private suspend fun speakWithSettings(text: String) {
        val s = app.settings
        app.speaker.speak(text, s.ttsLanguage.first(), s.ttsSpeed.first(), s.ttsPitch.first())
    }

    private fun recognizerLanguage(tts: String): String = tts

    override fun onCleared() {
        listener.destroy()
        super.onCleared()
    }
}
