package com.shivam.os.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shivam.os.data.NoteEntity
import com.shivam.os.ui.components.ConfirmDialog
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.NotesViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun NotesScreen() {
    val vm = shivamViewModel { NotesViewModel(it) }
    val notes by vm.notes.collectAsState()
    val query by vm.query.collectAsState()
    var editing by remember { mutableStateOf<NoteEntity?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<NoteEntity?>(null) }
    val stamp = remember { DateTimeFormatter.ofPattern("dd MMM, HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Notes", style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold, color = Neon, modifier = Modifier.weight(1f)
            )
            Button(onClick = { editing = null; showEditor = true }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("New note")
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { vm.setQuery(it) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Search title, text or category") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }
        )
        if (notes.isEmpty()) {
            GlassCard {
                Text(
                    if (query.isBlank()) "No notes yet. Tap New note, or tell Jarvis \"Notes mein likho ki …\"."
                    else "No notes match \"$query\".",
                    color = TextMuted
                )
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(notes, key = { it.id }) { note ->
                GlassCard(Modifier.clickable { editing = note; showEditor = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(note.title, fontWeight = FontWeight.SemiBold)
                            Text(note.category, style = MaterialTheme.typography.labelMedium, color = Neon)
                            if (note.body.isNotBlank()) {
                                Text(note.body.take(160), color = TextMuted, maxLines = 3)
                            }
                            Text(
                                stamp.format(Instant.ofEpochMilli(
                                    if (note.updatedAt > 0) note.updatedAt else note.createdAt
                                ).atZone(ZoneId.systemDefault())),
                                style = MaterialTheme.typography.labelSmall, color = TextMuted
                            )
                        }
                        IconButton(onClick = { toDelete = note }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete note", tint = Danger)
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        NoteEditor(
            existing = editing,
            onDismiss = { showEditor = false },
            onSave = { title, body, category, onResult ->
                val current = editing
                vm.save(current, title, body, category) { err ->
                    onResult(err)
                    if (err == null) showEditor = false
                }
            }
        )
    }

    toDelete?.let { note ->
        ConfirmDialog(
            title = "Delete note?",
            message = "\"${note.title}\" will be removed from this device.",
            confirmLabel = "Delete",
            onConfirm = { vm.delete(note); toDelete = null },
            onDismiss = { toDelete = null }
        )
    }
}

@Composable
private fun NoteEditor(
    existing: NoteEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, (String?) -> Unit) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var body by remember { mutableStateOf(existing?.body.orEmpty()) }
    var category by remember { mutableStateOf(existing?.category ?: "General") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "New note" else "Edit note") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Category") }, singleLine = true)
                OutlinedTextField(body, { body = it }, label = { Text("Note") }, minLines = 4)
                error?.let { Text(it, color = Danger) }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(title, body, category) { err -> error = err } }) {
                Text("Save", color = Neon)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
