package com.shivam.os.ai

import com.shivam.os.data.AppDatabase
import com.shivam.os.data.MessageEntity
import com.shivam.os.data.SettingsStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

/** Optimus Core: builds prompts, stores conversation memory and calls the configured provider. */
class ChatRepository(
    private val db: AppDatabase,
    private val settings: SettingsStore,
    private val client: AiClient = AiClient()
) {
    val messages: Flow<List<MessageEntity>> = db.messageDao().observeAll()

    /** Sends a chat message with conversation memory and stored facts. Persists both sides on success. */
    suspend fun send(userText: String): AiResult {
        val config = settings.aiConfig.first()
        val memoryOn = settings.memoryEnabled.first()

        db.messageDao().insert(MessageEntity(role = "user", content = userText))

        val history = if (memoryOn) {
            db.messageDao().latest(MAX_HISTORY).reversed()
                .map { ChatTurn(if (it.role == "assistant") "assistant" else "user", it.content) }
        } else {
            listOf(ChatTurn("user", userText))
        }
        val facts = if (memoryOn) db.memoryDao().all().map { it.fact } else emptyList()

        val result = client.complete(config, buildSystemPrompt(facts), history)
        if (result is AiResult.Ok) {
            db.messageDao().insert(MessageEntity(role = "assistant", content = result.text))
        }
        return result
    }

    /** One-shot AI call that is not added to chat history (used by Study Pilot). */
    suspend fun oneShot(system: String, prompt: String, maxTokens: Int = 1500): AiResult =
        client.complete(settings.aiConfig.first(), system, listOf(ChatTurn("user", prompt)), maxTokens)

    /** Stores a local (non-AI) exchange so it appears in the chat log. */
    suspend fun appendLocal(role: String, text: String) {
        db.messageDao().insert(MessageEntity(role = role, content = text))
    }

    suspend fun testConnection(config: AiConfig): AiResult = client.testConnection(config)

    private fun buildSystemPrompt(facts: List<String>): String = buildString {
        appendLine("You are Optimus Core, the AI assistant inside the SHIVAM OS Android app.")
        appendLine("Reply in the language the user writes in: English, Hindi, or Hinglish (Hindi in Roman script).")
        appendLine("Be concise. When asked to plan tasks, use numbered steps.")
        appendLine("You cannot control the device yourself. Device actions are handled by the app's own commands.")
        appendLine("Never claim you performed an action you did not perform.")
        if (facts.isNotEmpty()) {
            appendLine()
            appendLine("Facts the user asked you to remember:")
            facts.forEach { appendLine("- $it") }
        }
    }

    companion object {
        const val MAX_HISTORY = 20
    }
}
