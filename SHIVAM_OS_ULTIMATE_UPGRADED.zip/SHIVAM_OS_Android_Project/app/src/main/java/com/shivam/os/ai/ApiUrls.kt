package com.shivam.os.ai

/** Pure URL helpers, kept free of Android types so they can be unit tested on the JVM. */
object ApiUrls {

    fun validateBaseUrl(raw: String): String? {
        val url = raw.trim()
        if (url.isEmpty()) return "Base URL is empty."
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            return "Base URL must start with https:// (or http:// for a local server)."
        }
        if (url.contains(" ")) return "Base URL must not contain spaces."
        return null
    }

    /** Accepts a base such as https://host/v1 or a full .../chat/completions URL. */
    fun openAiChatCompletions(raw: String): String {
        val base = raw.trim().trimEnd('/')
        return if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
    }

    /** Accepts https://api.anthropic.com, https://api.anthropic.com/v1 or the full messages URL. */
    fun anthropicMessages(raw: String): String {
        val base = raw.trim().trimEnd('/')
        return when {
            base.endsWith("/v1/messages") -> base
            base.endsWith("/v1") -> "$base/messages"
            else -> "$base/v1/messages"
        }
    }
}
