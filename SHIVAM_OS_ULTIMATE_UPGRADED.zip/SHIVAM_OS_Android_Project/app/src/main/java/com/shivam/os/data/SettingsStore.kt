package com.shivam.os.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.shivam.os.ai.AiConfig
import com.shivam.os.ai.ProviderType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "shivam_settings")

/**
 * Settings live in app-private DataStore. API keys are entered by the user at runtime and are
 * never compiled into the APK. DataStore is not hardware-encrypted; see SETUP.md for hardening.
 */
class SettingsStore(private val context: Context) {

    private object Keys {
        val PROVIDER = stringPreferencesKey("provider")
        val BASE_URL = stringPreferencesKey("base_url")
        val MODEL = stringPreferencesKey("model")
        val API_KEY = stringPreferencesKey("api_key")
        val TTS_SPEED = floatPreferencesKey("tts_speed")
        val TTS_PITCH = floatPreferencesKey("tts_pitch")
        val TTS_LANGUAGE = stringPreferencesKey("tts_language")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val LAST_CONNECTION_STATUS = stringPreferencesKey("last_connection_status")
        val LAST_ERROR = stringPreferencesKey("last_error")
    }

    val aiConfig: Flow<AiConfig> = context.dataStore.data.map { p ->
        val provider = runCatching {
            ProviderType.valueOf(p[Keys.PROVIDER] ?: ProviderType.OPENAI_COMPATIBLE.name)
        }.getOrDefault(ProviderType.OPENAI_COMPATIBLE)
        AiConfig(
            provider = provider,
            baseUrl = p[Keys.BASE_URL] ?: provider.defaultBaseUrl,
            model = p[Keys.MODEL] ?: provider.defaultModel,
            apiKey = p[Keys.API_KEY].orEmpty()
        )
    }

    val ttsSpeed: Flow<Float> = context.dataStore.data.map { it[Keys.TTS_SPEED] ?: 1.0f }
    val ttsPitch: Flow<Float> = context.dataStore.data.map { it[Keys.TTS_PITCH] ?: 1.0f }
    val ttsLanguage: Flow<String> = context.dataStore.data.map { it[Keys.TTS_LANGUAGE] ?: "en-IN" }
    val memoryEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.MEMORY_ENABLED] ?: true }
    val lastConnectionStatus: Flow<String> = context.dataStore.data.map { it[Keys.LAST_CONNECTION_STATUS] ?: "Not tested" }
    val lastError: Flow<String> = context.dataStore.data.map { it[Keys.LAST_ERROR].orEmpty() }

    suspend fun saveAiConfig(config: AiConfig) {
        context.dataStore.edit {
            it[Keys.PROVIDER] = config.provider.name
            it[Keys.BASE_URL] = config.baseUrl.trim()
            it[Keys.MODEL] = config.model.trim()
            it[Keys.API_KEY] = config.apiKey.trim()
        }
    }

    suspend fun saveConnectionResult(status: String, error: String) {
        context.dataStore.edit {
            it[Keys.LAST_CONNECTION_STATUS] = status
            it[Keys.LAST_ERROR] = error
        }
    }

    suspend fun saveVoice(speed: Float, pitch: Float, language: String) {
        context.dataStore.edit {
            it[Keys.TTS_SPEED] = speed.coerceIn(0.5f, 2.0f)
            it[Keys.TTS_PITCH] = pitch.coerceIn(0.5f, 2.0f)
            it[Keys.TTS_LANGUAGE] = language
        }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MEMORY_ENABLED] = enabled }
    }

    suspend fun clearAll() {
        context.dataStore.edit { it.clear() }
    }
}
