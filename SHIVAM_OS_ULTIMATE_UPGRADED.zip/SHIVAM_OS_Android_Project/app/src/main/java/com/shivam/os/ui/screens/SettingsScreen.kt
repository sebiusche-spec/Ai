package com.shivam.os.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.shivam.os.ai.ProviderType
import com.shivam.os.control.PhoneActions
import com.shivam.os.control.SettingsPanel
import com.shivam.os.ui.components.ConfirmDialog
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.Success
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.util.shivam
import com.shivam.os.viewmodel.ConnectionState
import com.shivam.os.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch

private val VOICE_LANGUAGES = listOf("en-IN", "en-US", "en-GB", "hi-IN")

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val vm = shivamViewModel { SettingsViewModel(it) }
    val app = LocalContext.current.shivam()
    val scope = rememberCoroutineScope()
    val draft by vm.draft.collectAsState()
    val connection by vm.connection.collectAsState()
    val message by vm.message.collectAsState()
    val speed by vm.voiceSpeed.collectAsState()
    val pitch by vm.voicePitch.collectAsState()
    val language by vm.voiceLanguage.collectAsState()
    val memory by vm.memoryEnabled.collectAsState()
    val ttsStatus by app.speaker.engineStatus.collectAsState()

    var showKey by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var diagText by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---- AI provider ----
            GlassCard {
                Text("AI provider", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                Text(
                    "Your key is stored only on this device. It is never built into the APK. Anyone with a copy of an " +
                        "APK can extract strings from it, so use a key with a spending limit and rotate it if exposed.",
                    color = TextMuted, style = MaterialTheme.typography.bodySmall
                )
                ProviderType.entries.forEach { p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = draft.provider == p, onClick = { vm.onProviderChanged(p) })
                        Text(p.label)
                    }
                }
                OutlinedTextField(
                    value = draft.baseUrl,
                    onValueChange = { v -> vm.onDraftChanged { it.copy(baseUrl = v) } },
                    label = { Text("Base URL") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.model,
                    onValueChange = { v -> vm.onDraftChanged { it.copy(model = v) } },
                    label = { Text("Model name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = draft.apiKey,
                    onValueChange = { v -> vm.onDraftChanged { it.copy(apiKey = v) } },
                    label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Toggle key")
                        }
                    }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = vm::saveConfig) { Text("Save") }
                    OutlinedButton(onClick = vm::testConnection, enabled = connection !is ConnectionState.Testing) {
                        Text(if (connection is ConnectionState.Testing) "Testing…" else "Test connection")
                    }
                }
                when (val c = connection) {
                    ConnectionState.Idle -> Text("Not tested yet.", color = TextMuted)
                    ConnectionState.Testing -> Text("Contacting provider…", color = TextMuted)
                    is ConnectionState.Connected -> Text(c.message, color = Success)
                    is ConnectionState.Failed -> Text(c.message, color = Danger)
                }
                if (message.isNotBlank()) Text(message, color = Neon, style = MaterialTheme.typography.bodySmall)
            }

            // ---- Voice Lab ----
            GlassCard {
                Text("Voice Lab", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                Text(ttsStatus, color = TextMuted, style = MaterialTheme.typography.bodySmall)
                Text("Language", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    VOICE_LANGUAGES.forEach { tag ->
                        FilterChip(selected = language == tag, onClick = { vm.setVoice(speed, pitch, tag) }, label = { Text(tag) })
                    }
                }
                Text("Speed: ${"%.2f".format(speed)}×")
                Slider(value = speed, onValueChange = { vm.setVoice(it, pitch, language) }, valueRange = 0.5f..2f)
                Text("Pitch: ${"%.2f".format(pitch)}")
                Slider(value = pitch, onValueChange = { vm.setVoice(speed, it, language) }, valueRange = 0.5f..2f)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = vm::previewVoice) { Text("Preview") }
                    Button(onClick = vm::saveVoice) { Text("Save voice") }
                }
                Text(
                    "Installed voices depend on your device's text-to-speech engine. Missing languages can be added in Android Settings.",
                    color = TextMuted, style = MaterialTheme.typography.bodySmall
                )
            }

            // ---- Memory & privacy ----
            GlassCard {
                Text("Memory & privacy", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Conversation memory", modifier = Modifier.weight(1f))
                    Switch(checked = memory, onCheckedChange = vm::setMemoryEnabled,
                        colors = SwitchDefaults.colors(checkedTrackColor = Neon))
                }
                OutlinedButton(onClick = vm::clearConversations) { Text("Clear conversation history") }
                OutlinedButton(onClick = { scope.launch { diagText = vm.diagnostics() } }) { Text("View diagnostics") }
                Button(
                    onClick = { confirmDelete = true },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Danger)
                ) { Text("Delete all local data") }
            }

            // ---- Permissions ----
            PermissionsCard()

            GlassCard {
                Text("Limits", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                Text(
                    "SHIVAM OS cannot toggle Wi-Fi, Bluetooth or mobile data silently, cannot bypass Android's " +
                        "background limits, and cannot run unrestricted background listening. Alarms use AlarmManager; " +
                        "voice works while the app is open.",
                    color = TextMuted, style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "Delete all local data?",
            message = "This removes conversations, alarms, notes, memories, routines and your saved API key from this device. It cannot be undone.",
            confirmLabel = "Delete",
            onConfirm = { vm.deleteAllData(); confirmDelete = false },
            onDismiss = { confirmDelete = false }
        )
    }
    diagText?.let { text ->
        AlertDialog(
            onDismissRequest = { diagText = null },
            title = { Text("Diagnostics") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(text, style = MaterialTheme.typography.bodySmall) } },
            confirmButton = { TextButton(onClick = { diagText = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun PermissionsCard() {
    val context = LocalContext.current
    val mic = remember { mutableStateOf(granted(context, Manifest.permission.RECORD_AUDIO)) }
    val notif = remember { mutableStateOf(Build.VERSION.SDK_INT < 33 || granted(context, Manifest.permission.POST_NOTIFICATIONS)) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { mic.value = it }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notif.value = it }

    GlassCard {
        Text("Permissions", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
        PermissionRow("Microphone (voice commands)", mic.value) { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
        PermissionRow("Notifications (alarms)", notif.value) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
        PermissionRow("Exact alarms", (context.shivam().alarms.canUseExact())) {
            PhoneActions.openSettings(context, SettingsPanel.EXACT_ALARMS)
        }
        Text(
            "Flashlight: " + if (PhoneActions.hasFlashlight(context)) "available (no permission needed)" else "not on this device",
            color = TextMuted, style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun PermissionRow(label: String, granted: Boolean, onRequest: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        if (granted) Text("Allowed", color = Success)
        else OutlinedButton(onClick = onRequest) { Text("Allow") }
    }
}

private fun granted(context: android.content.Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
