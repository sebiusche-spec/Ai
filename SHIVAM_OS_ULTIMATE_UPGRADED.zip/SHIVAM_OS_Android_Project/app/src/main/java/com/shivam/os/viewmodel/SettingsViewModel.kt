package com.shivam.os.viewmodel

import android.Manifest
import android.app.AlarmManager
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.BuildConfig
import com.shivam.os.ShivamApp
import com.shivam.os.ai.AiConfig
import com.shivam.os.ai.AiResult
import com.shivam.os.ai.ProviderType
import com.shivam.os.control.PhoneActions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed interface ConnectionState {
    data object Idle : ConnectionState
    data object Testing : ConnectionState
    data class Connected(val message: String) : ConnectionState
    data class Failed(val message: String) : ConnectionState
}

class SettingsViewModel(private val app: ShivamApp) : ViewModel() {

    /** Draft config edited on screen; saved explicitly so a half-typed key never takes effect. */
    private val _draft = MutableStateFlow(AiConfig())
    val draft: StateFlow<AiConfig> = _draft.asStateFlow()

    private val _connection = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    val connection: StateFlow<ConnectionState> = _connection.asStateFlow()

    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message.asStateFlow()

    private val _voiceSpeed = MutableStateFlow(1f)
    val voiceSpeed: StateFlow<Float> = _voiceSpeed.asStateFlow()
    private val _voicePitch = MutableStateFlow(1f)
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()
    private val _voiceLanguage = MutableStateFlow("en-IN")
    val voiceLanguage: StateFlow<String> = _voiceLanguage.asStateFlow()

    val memoryEnabled: StateFlow<Boolean> = MutableStateFlow(true).also { flow ->
        viewModelScope.launch { app.settings.memoryEnabled.collect { flow.value = it } }
    }

    init {
        viewModelScope.launch {
            _draft.value = app.settings.aiConfig.first()
            _voiceSpeed.value = app.settings.ttsSpeed.first()
            _voicePitch.value = app.settings.ttsPitch.first()
            _voiceLanguage.value = app.settings.ttsLanguage.first()
        }
    }

    fun onProviderChanged(provider: ProviderType) {
        // Switching provider resets URL and model to that provider's defaults; the key is kept.
        _draft.value = _draft.value.copy(provider = provider, baseUrl = provider.defaultBaseUrl, model = provider.defaultModel)
    }

    fun onDraftChanged(transform: (AiConfig) -> AiConfig) { _draft.value = transform(_draft.value) }

    fun saveConfig() {
        val config = _draft.value
        config.validationError()?.let { _message.value = it; return }
        viewModelScope.launch {
            app.settings.saveAiConfig(config)
            _message.value = "Settings saved."
        }
    }

    fun testConnection() {
        val config = _draft.value
        config.validationError()?.let {
            _connection.value = ConnectionState.Failed(it)
            return
        }
        viewModelScope.launch {
            _connection.value = ConnectionState.Testing
            when (val r = app.chat.testConnection(config)) {
                is AiResult.Ok -> {
                    _connection.value = ConnectionState.Connected("Connected to ${config.model}")
                    app.settings.saveConnectionResult("Connected (${config.model})", "")
                }
                is AiResult.Error -> {
                    _connection.value = ConnectionState.Failed(r.message)
                    app.settings.saveConnectionResult("Failed", r.message)
                }
            }
        }
    }

    fun setVoice(speed: Float, pitch: Float, language: String) {
        _voiceSpeed.value = speed
        _voicePitch.value = pitch
        _voiceLanguage.value = language
    }

    fun saveVoice() {
        viewModelScope.launch {
            app.settings.saveVoice(_voiceSpeed.value, _voicePitch.value, _voiceLanguage.value)
            _message.value = "Voice settings saved."
        }
    }

    fun previewVoice() {
        val installed = app.speaker.configure(_voiceLanguage.value, _voiceSpeed.value, _voicePitch.value)
        if (!installed) {
            _message.value = "This language voice is not installed on the device. Install it in Android TTS settings."
            return
        }
        app.speaker.speak("SHIVAM OS voice check. Hello, main Optimus hoon.", _voiceLanguage.value, _voiceSpeed.value, _voicePitch.value)
    }

    fun setMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch { app.settings.setMemoryEnabled(enabled) }
    }

    fun clearConversations() {
        viewModelScope.launch {
            app.db.messageDao().clear()
            _message.value = "Conversation history cleared."
        }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            app.db.alarmDao().enabled().forEach { app.alarms.cancel(it.id) }
            app.db.deleteAllUserData()
            app.settings.clearAll()
            _draft.value = AiConfig()
            _connection.value = ConnectionState.Idle
            _message.value = "All local data deleted, including API settings."
        }
    }

    /** Diagnostics report for support. Never includes the API key. */
    suspend fun diagnostics(): String {
        val s = app.settings
        val exact = app.alarms.canUseExact()
        val notif = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val mic = ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val cfg = s.aiConfig.first()
        return buildString {
            appendLine("SHIVAM OS ${BuildConfig.VERSION_NAME} (${BuildConfig.BUILD_TYPE})")
            appendLine("Android API ${Build.VERSION.SDK_INT} on ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Provider: ${cfg.provider.name}, model: ${cfg.model}")
            appendLine("API key set: ${cfg.apiKey.isNotBlank()}")
            appendLine("Last connection: ${s.lastConnectionStatus.first()}")
            appendLine("Last error: ${s.lastError.first().ifBlank { "none" }}")
            appendLine("Exact alarms allowed: $exact")
            appendLine("Notifications allowed: $notif")
            appendLine("Microphone allowed: $mic")
            appendLine("Flashlight present: ${PhoneActions.hasFlashlight(app)}")
            appendLine("TTS: ${app.speaker.engineStatus.value}")
            appendLine("Memory enabled: ${s.memoryEnabled.first()}")
        }
    }
}
