package com.shivam.os.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shivam.os.data.AlarmEntity
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Schedules alarms with AlarmManager. Uses exact alarms when the user has granted
 * SCHEDULE_EXACT_ALARM (Android 12+); otherwise falls back to inexact-while-idle and reports it.
 */
class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canUseExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    /** Schedules the next occurrence of [alarm]. Returns true if the alarm is exact. */
    fun schedule(alarm: AlarmEntity, now: ZonedDateTime = ZonedDateTime.now()): Boolean {
        val trigger = AlarmTimeCalculator.nextTrigger(now, alarm.hour, alarm.minute, alarm.repeatDaysMask)
        return setAlarm(alarm.id, trigger)
    }

    fun snooze(alarmId: Int, minutes: Int = 10): Boolean {
        val trigger = System.currentTimeMillis() + minutes * 60_000L
        return setAlarm(snoozeRequestCode(alarmId), trigger, alarmId, snoozed = true)
    }

    fun cancel(alarmId: Int) {
        listOf(alarmId, snoozeRequestCode(alarmId)).forEach { code ->
            val pi = PendingIntent.getBroadcast(
                context, code, fireIntent(alarmId),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            pi?.let { alarmManager.cancel(it); it.cancel() }
        }
    }

    /** Re-registers every enabled alarm. Called after reboot, app update or exact-alarm permission change. */
    fun rescheduleAll(alarms: List<AlarmEntity>) {
        alarms.filter { it.enabled }.forEach { schedule(it) }
    }

    private fun setAlarm(requestCode: Int, triggerAt: Long, alarmId: Int = requestCode, snoozed: Boolean = false): Boolean {
        val pi = PendingIntent.getBroadcast(
            context, requestCode, fireIntent(alarmId, snoozed),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (canUseExact()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            true
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            false
        }
    }

    private fun fireIntent(alarmId: Int, snoozed: Boolean = false) = Intent(context, AlarmReceiver::class.java)
        .setAction(AlarmReceiver.ACTION_FIRE)
        .putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarmId)
        .putExtra(AlarmReceiver.EXTRA_SNOOZED, snoozed)

    private fun snoozeRequestCode(alarmId: Int) = 100_000 + alarmId

    companion object {
        fun zone(): ZoneId = ZoneId.systemDefault()
    }
}
