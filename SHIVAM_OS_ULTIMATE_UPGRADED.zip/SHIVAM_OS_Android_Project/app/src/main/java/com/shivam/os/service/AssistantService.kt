package com.shivam.os.service

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.shivam.os.MainActivity
import com.shivam.os.ShivamApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Process-wide status of the assistant service, observed by the dashboard. */
object AssistantRuntime {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _lastError = MutableStateFlow("")
    val lastError: StateFlow<String> = _lastError.asStateFlow()

    internal fun update(running: Boolean, error: String = "") {
        _running.value = running
        _lastError.value = error
    }
}

/**
 * User-started foreground service that shows a persistent "Jarvis is active" notification with a Stop action.
 *
 * It does NOT listen to the microphone by itself. Voice recognition runs only while the app is open, as
 * described in UPGRADE_NOTES.md. Because the service never records audio, it does not declare the
 * microphone foreground-service type. It restarts only when the user starts it again (START_NOT_STICKY).
 */
class AssistantService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAssistant()
            return START_NOT_STICKY
        }
        return try {
            startAsForeground()
            AssistantRuntime.update(running = true)
            START_NOT_STICKY
        } catch (e: Exception) {
            // Covers Android 12+ foreground-start restrictions and missing notification channels.
            AssistantRuntime.update(running = false, error = "Could not start the assistant (${e.javaClass.simpleName}).")
            stopSelf()
            START_NOT_STICKY
        }
    }

    override fun onDestroy() {
        AssistantRuntime.update(running = false)
        super.onDestroy()
    }

    private fun stopAssistant() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        AssistantRuntime.update(running = false)
        stopSelf()
    }

    private fun startAsForeground() {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, ShivamApp.CHANNEL_SERVICE)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Jarvis is active")
            .setContentText("Open SHIVAM OS to talk. Stop ends the assistant.")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Stop assistant", stop)
            .build()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
    }

    companion object {
        const val ACTION_STOP = "com.shivam.os.action.ASSISTANT_STOP"
        const val NOTIFICATION_ID = 7001

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, AssistantService::class.java))
        }

        fun stop(context: Context) {
            try {
                context.startService(Intent(context, AssistantService::class.java).setAction(ACTION_STOP))
            } catch (e: IllegalStateException) {
                AssistantRuntime.update(running = false, error = "Could not stop the assistant service.")
            }
        }
    }
}
