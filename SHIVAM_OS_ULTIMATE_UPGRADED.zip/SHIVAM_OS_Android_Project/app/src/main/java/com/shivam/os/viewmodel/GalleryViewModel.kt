package com.shivam.os.viewmodel

import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.data.GalleryItemEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Stores only URIs returned by the photo picker. No storage permission is requested or used. */
class GalleryViewModel(private val app: ShivamApp) : ViewModel() {

    val items: StateFlow<List<GalleryItemEntity>> = app.db.galleryDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            uris.forEach { uri ->
                // Keep read access across restarts if the picker grants it; ignore if it does not.
                runCatching {
                    app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                app.db.galleryDao().insert(GalleryItemEntity(uri = uri.toString()))
            }
        }
    }

    /** Removes the entry from SHIVAM OS only. The photo itself is not deleted. */
    fun remove(item: GalleryItemEntity) {
        viewModelScope.launch { app.db.galleryDao().delete(item) }
    }
}
