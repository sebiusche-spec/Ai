package com.shivam.os.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.channels.awaitClose
import java.time.ZonedDateTime

data class BatteryState(val percent: Int, val charging: Boolean)

/**
 * Live system status. Battery and network reads need no dangerous permissions
 * (ACCESS_NETWORK_STATE is a normal permission). Flows unregister their receivers when collection stops.
 */
object SystemStatus {

    fun battery(context: Context): Flow<BatteryState> = callbackFlow {
        fun parse(i: Intent): BatteryState {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            return BatteryState(pct, charging)
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                trySend(parse(i))
            }
        }
        context.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { trySend(parse(it)) }
        awaitClose { context.unregisterReceiver(receiver) }
    }.distinctUntilChanged()

    fun network(context: Context): Flow<String> = callbackFlow {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        fun current(): String {
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "Offline"
            return when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> "Connected"
                else -> "No internet"
            }
        }
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                trySend(current())
            }
            override fun onLost(network: Network) {
                trySend(current())
            }
        }
        trySend(current())
        cm.registerDefaultNetworkCallback(callback)
        awaitClose { cm.unregisterNetworkCallback(callback) }
    }.distinctUntilChanged()

    /** Emits once per minute, aligned to the minute boundary. Recomputes from the system clock, so clock and time-zone changes are picked up. */
    fun minuteClock(): Flow<ZonedDateTime> = flow {
        while (true) {
            emit(ZonedDateTime.now())
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
}
