package com.shivam.os.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

/** Text-to-speech wrapper with user-tunable language, speed and pitch, plus an interrupt control. */
class Speaker(context: Context) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var pendingSpeech: (() -> Unit)? = null

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private val _engineStatus = MutableStateFlow("Initializing TTS engine…")
    val engineStatus: StateFlow<String> = _engineStatus.asStateFlow()

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            _engineStatus.value = "No text-to-speech engine available. Install one in Android Settings."
            return
        }
        ready = true
        _engineStatus.value = "TTS ready (${tts.defaultEngine})"
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { _speaking.value = true }
            override fun onDone(utteranceId: String?) { _speaking.value = false }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { _speaking.value = false }
        })
        pendingSpeech?.invoke()
        pendingSpeech = null
    }

    fun availableEngines(): List<String> = tts.engines.map { it.label }

    fun availableLanguages(): List<Locale> = tts.availableLanguages?.sortedBy { it.toLanguageTag() } ?: emptyList()

    /** Applies language, speed and pitch. Returns false if the language is not installed. */
    fun configure(language: String, speed: Float, pitch: Float): Boolean {
        if (!ready) return false
        val locale = Locale.forLanguageTag(language)
        val support = tts.isLanguageAvailable(locale)
        if (support == TextToSpeech.LANG_NOT_SUPPORTED || support == TextToSpeech.LANG_MISSING_DATA) {
            return false
        }
        tts.language = locale
        tts.setSpeechRate(speed.coerceIn(0.5f, 2.0f))
        tts.setPitch(pitch.coerceIn(0.5f, 2.0f))
        return true
    }

    fun speak(text: String, language: String = "en-IN", speed: Float = 1f, pitch: Float = 1f) {
        val action: () -> Unit = {
            configure(language, speed, pitch)
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        }
        if (ready) {
            action()
        } else {
            pendingSpeech = action
        }
    }

    /** Interrupt control: stop speaking immediately. */
    fun stop() {
        if (ready) tts.stop()
        _speaking.value = false
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }

    fun voiceNames(): List<Voice> = if (ready) tts.voices.toList() else emptyList()
}
