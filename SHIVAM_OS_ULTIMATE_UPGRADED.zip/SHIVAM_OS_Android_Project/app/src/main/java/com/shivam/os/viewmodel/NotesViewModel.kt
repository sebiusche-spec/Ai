package com.shivam.os.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.data.NoteEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NotesViewModel(private val app: ShivamApp) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val notes: StateFlow<List<NoteEntity>> = combine(app.db.noteDao().observeAll(), _query) { list, q ->
        if (q.isBlank()) list else list.filter {
            it.title.contains(q, ignoreCase = true) ||
                it.body.contains(q, ignoreCase = true) ||
                it.category.contains(q, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun setQuery(q: String) { _query.value = q }

    /** Creates a note when [existing] is null, otherwise updates it. Returns an error string or null. */
    fun save(existing: NoteEntity?, title: String, body: String, category: String, onResult: (String?) -> Unit) {
        if (title.isBlank() && body.isBlank()) {
            onResult("Write a title or some text before saving.")
            return
        }
        val now = System.currentTimeMillis()
        viewModelScope.launch {
            val cleanTitle = title.trim().ifBlank { "Untitled" }
            val cleanCategory = category.trim().ifBlank { "General" }
            if (existing == null) {
                app.db.noteDao().insert(NoteEntity(title = cleanTitle, body = body, category = cleanCategory,
                    createdAt = now, updatedAt = now))
            } else {
                app.db.noteDao().update(existing.copy(title = cleanTitle, body = body,
                    category = cleanCategory, updatedAt = now))
            }
            onResult(null)
        }
    }

    fun delete(note: NoteEntity) {
        viewModelScope.launch { app.db.noteDao().delete(note) }
    }
}
