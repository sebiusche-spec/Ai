package com.shivam.os.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.alarm.AlarmTimeCalculator
import com.shivam.os.data.AlarmEntity
import com.shivam.os.service.AssistantRuntime
import com.shivam.os.service.AssistantService
import com.shivam.os.util.BatteryState
import com.shivam.os.util.SystemStatus
import java.time.ZonedDateTime
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AlarmUi(val alarm: AlarmEntity, val nextMillis: Long)

class HomeViewModel(private val app: ShivamApp) : ViewModel() {

    /** Display name for the greeting. A name editor is not part of this build. */
    val name: String = DISPLAY_NAME

    private val stopPolicy = SharingStarted.WhileSubscribed(5_000)

    val now: StateFlow<ZonedDateTime> = SystemStatus.minuteClock()
        .stateIn(viewModelScope, stopPolicy, ZonedDateTime.now())

    val battery: StateFlow<BatteryState> = SystemStatus.battery(app)
        .stateIn(viewModelScope, stopPolicy, BatteryState(-1, false))

    val network: StateFlow<String> = SystemStatus.network(app)
        .stateIn(viewModelScope, stopPolicy, "Checking…")

    val aiStatus: StateFlow<String> = app.settings.lastConnectionStatus
        .stateIn(viewModelScope, stopPolicy, "Not tested")

    val serviceRunning: StateFlow<Boolean> = AssistantRuntime.running
    val serviceError: StateFlow<String> = AssistantRuntime.lastError

    val upcomingAlarms: StateFlow<List<AlarmUi>> = combine(app.db.alarmDao().observeAll(), now) { list, n ->
        list.filter { it.enabled }
            .map { AlarmUi(it, AlarmTimeCalculator.nextTrigger(n, it.hour, it.minute, it.repeatDaysMask)) }
            .sortedBy { it.nextMillis }
    }.stateIn(viewModelScope, stopPolicy, emptyList())

    val recentCommands: StateFlow<List<String>> = app.db.messageDao().observeAll()
        .map { msgs -> msgs.filter { it.role == "user" }.takeLast(3).reversed().map { it.content } }
        .stateIn(viewModelScope, stopPolicy, emptyList())

    private val _lastReply = MutableStateFlow("")
    val lastReply: StateFlow<String> = _lastReply.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    /** Sends a typed command through the same pipeline as voice and chat. */
    fun send(text: String) {
        if (text.isBlank() || _busy.value) return
        viewModelScope.launch {
            _busy.value = true
            try {
                _lastReply.value = app.assistant.handle(text).text
            } finally {
                _busy.value = false
            }
        }
    }

    fun startAssistant() = AssistantService.start(app)
    fun stopAssistant() = AssistantService.stop(app)

    /** Returns false (and does nothing) if no app can handle the intent. Callers show the message. */
    fun openIntent(context: Context, intent: Intent): Boolean {
        if (intent.resolveActivity(context.packageManager) == null) return false
        context.startActivity(intent)
        return true
    }

    fun browserIntent(): Intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))

    companion object {
        const val DISPLAY_NAME = "Shivam"
    }
}
