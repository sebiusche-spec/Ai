package com.shivam.os.util

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.shivam.os.ShivamApp

fun Context.shivam(): ShivamApp = applicationContext as ShivamApp

/** Creates a ViewModel that receives the application service container. */
@Composable
inline fun <reified VM : ViewModel> shivamViewModel(crossinline create: (ShivamApp) -> VM): VM {
    val app = LocalContext.current.shivam()
    return viewModel(factory = viewModelFactory { initializer { create(app) } })
}
