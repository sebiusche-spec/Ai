package com.shivam.os.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,          // "user" | "assistant" | "system"
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val label: String,
    /** Bitmask: bit 0 = Sunday ... bit 6 = Saturday. 0 = one-shot. */
    val repeatDaysMask: Int = 0,
    val enabled: Boolean = true
)

/** Schema v2 added category and updatedAt. Defaults match MIGRATION_1_2 exactly. */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "'General'") val category: String = "General",
    @ColumnInfo(defaultValue = "0") val updatedAt: Long = 0L
)

/** Photos chosen with the Android photo picker. Only the content URI is stored, never the file. */
@Entity(tableName = "gallery_items")
data class GalleryItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val addedAt: Long = System.currentTimeMillis()
)

/** Facts the user explicitly asked the assistant to remember ("remember that ..."). */
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fact: String,
    val createdAt: Long = System.currentTimeMillis()
)

/** Command Studio routine: when input contains triggerPhrase, run the action. */
@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val triggerPhrase: String,
    val actionType: String,
    val actionValue: String = "",
    val enabled: Boolean = true
)
