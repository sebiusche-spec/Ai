package com.shivam.os.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.BatteryState
import com.shivam.os.util.SystemStatus
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun ToolsScreen(onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    val clock by remember { SystemStatus.minuteClock() }.collectAsState(initial = ZonedDateTime.now())
    val battery by remember(context) { SystemStatus.battery(context) }
        .collectAsState(initial = BatteryState(-1, false))

    var running by remember { mutableStateOf(false) }
    var elapsedMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(running) {
        if (running) {
            val base = System.currentTimeMillis() - elapsedMs
            while (true) {
                elapsedMs = System.currentTimeMillis() - base
                delay(100)
            }
        }
    }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Tools", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Neon)

        GlassCard {
            Text("Clock", style = MaterialTheme.typography.labelMedium, color = Neon)
            Text(
                clock.format(DateTimeFormatter.ofPattern("hh:mm:ss a", Locale.getDefault())),
                style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Light
            )
            Text(clock.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", Locale.getDefault())), color = TextMuted)
        }

        GlassCard {
            Text("Stopwatch", style = MaterialTheme.typography.labelMedium, color = Neon)
            Text(formatStopwatch(elapsedMs), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Light)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { running = !running }) { Text(if (running) "Pause" else "Start") }
                OutlinedButton(onClick = { running = false; elapsedMs = 0L }) { Text("Reset") }
            }
        }

        GlassCard {
            Text("Battery", style = MaterialTheme.typography.labelMedium, color = Neon)
            Text(
                when {
                    battery.percent < 0 -> "Battery level is not available on this device."
                    battery.charging -> "${battery.percent}% · charging"
                    else -> "${battery.percent}%"
                }
            )
            LinearProgressIndicator(
                progress = { if (battery.percent >= 0) battery.percent / 100f else 0f },
                modifier = Modifier.fillMaxWidth()
            )
        }

        GlassCard {
            Text("Open tools", style = MaterialTheme.typography.labelMedium, color = Neon)
            ToolButton("Timer and countdown", Icons.Default.Timer) { onNavigate("timer") }
            ToolButton("Control center (apps, flashlight, settings)", Icons.Default.Build) { onNavigate("control") }
            ToolButton("Alarm manager", Icons.Default.Alarm) { onNavigate("alarms") }
            ToolButton("Reminder manager (one-time and repeating alarms)", Icons.Default.Notifications) { onNavigate("reminders") }
            ToolButton("Voice test and speech recognition test", Icons.Default.Mic) { onNavigate("jarvis") }
            ToolButton("AI connection test", Icons.Default.Settings) { onNavigate("settings") }
            ToolButton("Permissions and diagnostics", Icons.Default.Settings) { onNavigate("settings") }
            ToolButton("Study Pilot (explain, summarize, quiz)", Icons.Default.Build) { onNavigate("study") }
        }
    }
}

@Composable
private fun ToolButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}

private fun formatStopwatch(ms: Long): String {
    val totalCs = ms / 10
    val cs = totalCs % 100
    val s = (totalCs / 100) % 60
    val m = (totalCs / 6000) % 60
    val h = totalCs / 360000
    return if (h > 0) String.format("%d:%02d:%02d.%02d", h, m, s, cs)
    else String.format("%02d:%02d.%02d", m, s, cs)
}
