package com.shivam.os.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.data.RoutineEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class StudioViewModel(private val app: ShivamApp) : ViewModel() {

    val routines: StateFlow<List<RoutineEntity>> = app.db.routineDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _lastRun = MutableStateFlow("")
    val lastRun: StateFlow<String> = _lastRun.asStateFlow()

    /** Returns an error message, or null if saved. */
    fun save(name: String, trigger: String, actionType: RoutineAction, value: String, onResult: (String?) -> Unit) {
        when {
            name.isBlank() -> onResult("Give the routine a name.")
            trigger.isBlank() -> onResult("Add a trigger phrase, for example \"movie time\".")
            actionType in setOf(RoutineAction.OPEN_APP, RoutineAction.SPEAK, RoutineAction.ASK_AI) && value.isBlank() ->
                onResult("This action needs a value.")
            else -> viewModelScope.launch {
                app.db.routineDao().insert(RoutineEntity(name = name.trim(), triggerPhrase = trigger.trim(),
                    actionType = actionType.name, actionValue = value.trim()))
                onResult(null)
            }
        }
    }

    fun toggle(routine: RoutineEntity) {
        viewModelScope.launch { app.db.routineDao().update(routine.copy(enabled = !routine.enabled)) }
    }

    fun delete(routine: RoutineEntity) {
        viewModelScope.launch { app.db.routineDao().delete(routine) }
    }

    fun test(routine: RoutineEntity) {
        viewModelScope.launch {
            val reply = app.assistant.runRoutine(routine)
            _lastRun.value = reply.text
            val s = app.settings
            app.speaker.speak(reply.text, s.ttsLanguage.first(), s.ttsSpeed.first(), s.ttsPitch.first())
        }
    }
}
