package com.shivam.os.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.data.AlarmEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AlarmViewModel(private val app: ShivamApp) : ViewModel() {

    val alarms: StateFlow<List<AlarmEntity>> = app.db.alarmDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Exact alarms require the user's permission on Android 12+. Reported so the UI can explain. */
    fun canScheduleExact(): Boolean = app.alarms.canUseExact()

    fun add(hour: Int, minute: Int, label: String, repeatMask: Int, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            val id = app.db.alarmDao().insert(
                AlarmEntity(hour = hour, minute = minute, label = label.ifBlank { "Alarm" }, repeatDaysMask = repeatMask)
            )
            val exact = app.alarms.schedule(AlarmEntity(id = id.toInt(), hour = hour, minute = minute,
                label = label.ifBlank { "Alarm" }, repeatDaysMask = repeatMask))
            onDone(exact)
        }
    }

    fun toggle(alarm: AlarmEntity) {
        viewModelScope.launch {
            val updated = alarm.copy(enabled = !alarm.enabled)
            app.db.alarmDao().update(updated)
            if (updated.enabled) app.alarms.schedule(updated) else app.alarms.cancel(alarm.id)
        }
    }

    fun delete(alarm: AlarmEntity) {
        viewModelScope.launch {
            app.alarms.cancel(alarm.id)
            app.db.alarmDao().delete(alarm)
        }
    }
}
