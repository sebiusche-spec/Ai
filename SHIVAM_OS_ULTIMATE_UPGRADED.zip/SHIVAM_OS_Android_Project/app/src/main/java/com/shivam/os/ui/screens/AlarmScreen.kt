package com.shivam.os.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.shivam.os.alarm.AlarmTimeCalculator
import com.shivam.os.control.PhoneActions
import com.shivam.os.control.SettingsPanel
import com.shivam.os.data.AlarmEntity
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.components.StatusPill
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.AlarmViewModel

private val DAY_LABELS = listOf("S", "M", "T", "W", "T", "F", "S")

@Composable
fun AlarmScreen() {
    val vm = shivamViewModel { AlarmViewModel(it) }
    val context = LocalContext.current
    val alarms by vm.alarms.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val exact = vm.canScheduleExact()

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Chronexa", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Neon)
        Text("Alarms and reminders", color = TextMuted)
        Spacer16()

        if (!exact) {
            GlassCard {
                Text("Exact alarms are off", fontWeight = FontWeight.SemiBold)
                Text(
                    "Alarms still fire, but may be delayed by Android's battery rules. Allow exact alarms for precise timing.",
                    color = TextMuted, style = MaterialTheme.typography.bodyMedium
                )
                OutlinedButton(onClick = { PhoneActions.openSettings(context, SettingsPanel.EXACT_ALARMS) }) {
                    Text("Allow exact alarms")
                }
            }
            Spacer16()
        }

        if (alarms.isEmpty()) {
            GlassCard {
                Text("No alarms yet. Tap + to add one, or say \"alarm 6:30 am\" in Optimus.", color = TextMuted)
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            items(alarms, key = { it.id }) { alarm ->
                AlarmCard(
                    alarm = alarm,
                    onToggle = { vm.toggle(alarm) },
                    onDelete = { vm.delete(alarm) }
                )
            }
        }

        if (message.isNotBlank()) {
            StatusPill(message, color = if (message.startsWith("!")) Danger else Neon)
        }
    }

    FloatingActionButton(
        modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        onClick = {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            showAdd = true
        },
        containerColor = Neon
    ) { Icon(Icons.Default.Add, contentDescription = "Add alarm") }

    if (showAdd) {
        AddAlarmDialog(
            onDismiss = { showAdd = false },
            onSave = { hour, minute, label, mask ->
                vm.add(hour, minute, label, mask) { isExact ->
                    message = if (isExact) "Alarm saved" else "! Saved, but not exact (see banner)"
                }
                showAdd = false
            }
        )
    }
    }
}

@Composable
private fun Spacer16() = androidx.compose.foundation.layout.Spacer(Modifier.padding(6.dp))

@Composable
private fun AlarmCard(alarm: AlarmEntity, onToggle: () -> Unit, onDelete: () -> Unit) {
    GlassCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    String.format("%02d:%02d", alarm.hour, alarm.minute),
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Light,
                    color = if (alarm.enabled) Neon else TextMuted
                )
                Text(alarm.label, fontWeight = FontWeight.Medium)
                Text(AlarmTimeCalculator.repeatLabel(alarm.repeatDaysMask), color = TextMuted,
                    style = MaterialTheme.typography.labelMedium)
            }
            Switch(
                checked = alarm.enabled,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(checkedTrackColor = Neon)
            )
            TextButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Delete alarm", tint = Danger) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddAlarmDialog(onDismiss: () -> Unit, onSave: (Int, Int, String, Int) -> Unit) {
    val now = java.time.LocalTime.now()
    val timeState = rememberTimePickerState(initialHour = now.hour, initialMinute = now.minute, is24Hour = false)
    var label by remember { mutableStateOf("") }
    var mask by remember { mutableStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New alarm") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                TimePicker(state = timeState)
                OutlinedTextField(
                    value = label, onValueChange = { label = it },
                    label = { Text("Label") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Text("Repeat (none = once)", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    DAY_LABELS.forEachIndexed { i, d ->
                        val bit = 1 shl i
                        FilterChip(
                            selected = mask and bit != 0,
                            onClick = { mask = mask xor bit },
                            label = { Text(d) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(timeState.hour, timeState.minute, label.trim(), mask) }) {
                Text("Save", color = Neon)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
