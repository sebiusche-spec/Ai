package com.shivam.os.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.shivam.os.ui.components.AiCore
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.components.StatusPill
import com.shivam.os.ui.components.Waveform
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.NeonViolet
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.VoiceViewModel

@Composable
fun VoiceScreen() {
    val vm = shivamViewModel { VoiceViewModel(it) }
    val context = LocalContext.current
    val listening by vm.listening.collectAsState()
    val speaking by vm.speaking.collectAsState()
    val level by vm.level.collectAsState()
    val partial by vm.partial.collectAsState()
    val heard by vm.heard.collectAsState()
    val reply by vm.reply.collectAsState()
    val status by vm.status.collectAsState()
    val engine by vm.engineStatus.collectAsState()
    var typed by remember { mutableStateOf("") }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startListening() else vm.onMicPermissionDenied()
    }

    fun toggleMic() {
        if (listening) { vm.stopListening(); return }
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.startListening() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("JARVIS", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Neon)
        StatusPill(status)

        AiCore(active = listening || speaking, level = level)
        Waveform(active = listening || speaking, level = level)

        if (partial.isNotBlank()) Text(partial, color = TextMuted, style = MaterialTheme.typography.bodyLarge)

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = { toggleMic() },
                colors = ButtonDefaults.buttonColors(containerColor = if (listening) Danger else Neon)
            ) {
                Icon(if (listening) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (listening) "Stop" else "Speak")
            }
            OutlinedButton(onClick = vm::interrupt) {
                Icon(Icons.Default.Close, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Interrupt")
            }
        }

        OutlinedButton(onClick = vm::morningBrief) {
            Icon(Icons.Default.WbSunny, contentDescription = null, tint = NeonViolet)
            Spacer(Modifier.width(6.dp))
            Text("Morning brief")
        }

        if (heard.isNotBlank()) {
            GlassCard {
                Text("You", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                Text(heard)
            }
        }
        if (reply.isNotBlank()) {
            GlassCard {
                Text("SHIVAM", style = MaterialTheme.typography.labelMedium, color = Neon)
                Text(reply)
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                placeholder = { Text("Or type a command") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            IconButton(onClick = {
                if (typed.isNotBlank()) { vm.submitTyped(typed); typed = "" }
            }) { Icon(Icons.Default.Mic, contentDescription = "Run typed command", tint = Neon) }
        }

        Text(engine, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text(
            "Voice works while the app is open. Background wake-word listening is not included: Android " +
                "restricts always-on microphone access, and a foreground-service mic session needs a visible notification.",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
    }
}
