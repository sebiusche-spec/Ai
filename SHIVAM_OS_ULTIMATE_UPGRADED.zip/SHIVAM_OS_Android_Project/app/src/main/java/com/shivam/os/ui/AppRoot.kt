package com.shivam.os.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shivam.os.ui.components.CinematicBackground
import com.shivam.os.ui.screens.AlarmScreen
import com.shivam.os.ui.screens.ControlScreen
import com.shivam.os.ui.screens.GalleryScreen
import com.shivam.os.ui.screens.HomeScreen
import com.shivam.os.ui.screens.JarvisScreen
import com.shivam.os.ui.screens.NotesScreen
import com.shivam.os.ui.screens.SettingsScreen
import com.shivam.os.ui.screens.StudyScreen
import com.shivam.os.ui.screens.ToolsScreen
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.SurfaceGlass
import com.shivam.os.ui.theme.TextMuted

/** Left navigation panel items, in the order of the reference design. */
enum class NavItem(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Default.Home),
    SETTINGS("settings", "Settings", Icons.Default.Settings),
    JARVIS("jarvis", "Jarvis", Icons.Default.Mic),
    ALARMS("alarms", "Alarms", Icons.Default.Alarm),
    REMINDERS("reminders", "Reminders", Icons.Default.Notifications),
    NOTES("notes", "Notes", Icons.Default.Edit),
    GALLERY("gallery", "Gallery", Icons.Default.Image),
    TOOLS("tools", "Tools", Icons.Default.Build)
}

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route

    val go: (String) -> Unit = { target ->
        nav.navigate(target) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Box(Modifier.fillMaxSize()) {
        CinematicBackground()
        Row(Modifier.fillMaxSize().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SideNav(selectedRoute = route, onSelect = go)
            NavHost(
                navController = nav,
                startDestination = NavItem.HOME.route,
                modifier = Modifier.weight(1f).fillMaxHeight()
            ) {
                composable("home") { HomeScreen(onNavigate = go) }
                composable("jarvis") { JarvisScreen(onOpenSettings = { go("settings") }) }
                composable("alarms") { AlarmScreen() }
                composable("reminders") { AlarmScreen() }
                composable("notes") { NotesScreen() }
                composable("gallery") { GalleryScreen() }
                composable("tools") { ToolsScreen(onNavigate = go) }
                composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
                composable("control") { ControlScreen(initialTab = 0) }
                composable("timer") { ControlScreen(initialTab = 2) }
                composable("study") { StudyScreen() }
            }
        }
    }
}

@Composable
private fun SideNav(selectedRoute: String?, onSelect: (String) -> Unit) {
    Column(
        Modifier
            .width(92.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(24.dp))
            .background(SurfaceGlass)
            .border(1.dp, Neon.copy(alpha = 0.25f), RoundedCornerShape(24.dp))
            .padding(8.dp)
    ) {
        Text(
            "SHIVAM", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
            color = Neon, modifier = Modifier.padding(start = 4.dp)
        )
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            NavItem.entries.forEach { item ->
                val selected = item.route == selectedRoute
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (selected) Neon.copy(alpha = 0.18f) else Color.Transparent)
                        .border(
                            1.dp,
                            if (selected) Neon.copy(alpha = 0.5f) else Color.Transparent,
                            RoundedCornerShape(16.dp)
                        )
                        .clickable(role = Role.Tab) { onSelect(item.route) }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        item.icon,
                        contentDescription = item.label,
                        tint = if (selected) Neon else TextMuted
                    )
                    Text(
                        item.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) Neon else TextMuted
                    )
                }
            }
        }
    }
}
