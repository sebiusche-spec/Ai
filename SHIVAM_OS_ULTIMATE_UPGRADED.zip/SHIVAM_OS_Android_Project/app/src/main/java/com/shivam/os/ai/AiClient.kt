package com.shivam.os.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Provider adapters. Each provider speaks its own wire format; the rest of the app only sees
 * [AiResult]. Keys are passed per request and never logged.
 */
class AiClient(
    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    private val json = "application/json; charset=utf-8".toMediaType()

    suspend fun complete(
        config: AiConfig,
        system: String,
        turns: List<ChatTurn>,
        maxTokens: Int = 1024
    ): AiResult {
        config.validationError()?.let { return AiResult.Error(it) }
        return withContext(Dispatchers.IO) {
            try {
                when (config.provider) {
                    ProviderType.OPENAI_COMPATIBLE -> openAi(config, system, turns, maxTokens)
                    ProviderType.ANTHROPIC -> anthropic(config, system, turns, maxTokens)
                }
            } catch (e: IOException) {
                AiResult.Error("Network error: could not reach ${config.baseUrl}. Check your connection and base URL.")
            } catch (e: Exception) {
                AiResult.Error("Unexpected response from provider: ${e.javaClass.simpleName}")
            }
        }
    }

    /** Sends a tiny request to verify key, base URL and model. */
    suspend fun testConnection(config: AiConfig): AiResult =
        complete(config, "Reply with exactly: OK", listOf(ChatTurn("user", "ping")), maxTokens = 16)

    private fun openAi(config: AiConfig, system: String, turns: List<ChatTurn>, maxTokens: Int): AiResult {
        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", system))
            turns.forEach { put(JSONObject().put("role", it.role).put("content", it.content)) }
        }
        val body = JSONObject()
            .put("model", config.model)
            .put("messages", messages)
            .put("max_tokens", maxTokens)
            .put("temperature", 0.6)

        val request = Request.Builder()
            .url(ApiUrls.openAiChatCompletions(config.baseUrl))
            .header("Authorization", "Bearer ${config.apiKey}")
            .post(body.toString().toRequestBody(json))
            .build()

        return execute(request) { raw ->
            val content = JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content")
            if (content.isBlank()) AiResult.Error("The model returned an empty reply.") else AiResult.Ok(content.trim())
        }
    }

    private fun anthropic(config: AiConfig, system: String, turns: List<ChatTurn>, maxTokens: Int): AiResult {
        val messages = JSONArray().apply {
            turns.forEach { put(JSONObject().put("role", it.role).put("content", it.content)) }
        }
        val body = JSONObject()
            .put("model", config.model)
            .put("system", system)
            .put("messages", messages)
            .put("max_tokens", maxTokens)

        val request = Request.Builder()
            .url(ApiUrls.anthropicMessages(config.baseUrl))
            .header("x-api-key", config.apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody(json))
            .build()

        return execute(request) { raw ->
            val blocks = JSONObject(raw).getJSONArray("content")
            val text = buildString {
                for (i in 0 until blocks.length()) {
                    val block = blocks.getJSONObject(i)
                    if (block.optString("type") == "text") append(block.optString("text"))
                }
            }.trim()
            if (text.isBlank()) AiResult.Error("The model returned an empty reply.") else AiResult.Ok(text)
        }
    }

    private inline fun execute(request: Request, parse: (String) -> AiResult): AiResult {
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) return AiResult.Error(mapHttpError(response.code, raw))
            return parse(raw)
        }
    }

    companion object {
        /** Maps HTTP failures to actionable messages. Never echoes the API key. */
        fun mapHttpError(code: Int, raw: String): String {
            val detail = runCatching {
                JSONObject(raw).optJSONObject("error")?.optString("message")
                    ?: JSONObject(raw).optString("message")
            }.getOrNull().orEmpty().take(200)
            return when (code) {
                400 -> "Bad request ($code). Check the model name. $detail".trim()
                401 -> "Invalid API key (401). Re-enter the key in Settings."
                403 -> "Access denied (403). This key may not have permission for the selected model."
                404 -> "Endpoint or model not found (404). Check the base URL and model name."
                408, 504 -> "The provider timed out ($code). Try again."
                429 -> "Rate limit or quota exceeded (429). Wait a moment or check your provider billing."
                in 500..599 -> "Provider server error ($code). Try again later."
                else -> "Unexpected HTTP $code. $detail".trim()
            }
        }
    }
}
