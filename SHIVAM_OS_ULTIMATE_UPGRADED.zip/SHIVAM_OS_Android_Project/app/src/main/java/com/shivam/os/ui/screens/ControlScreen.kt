package com.shivam.os.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shivam.os.control.ActionResult
import com.shivam.os.control.SettingsPanel
import com.shivam.os.data.RoutineEntity
import com.shivam.os.ui.components.ConfirmDialog
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.components.StatusPill
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.Success
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.ControlViewModel
import com.shivam.os.viewmodel.RoutineAction
import com.shivam.os.viewmodel.StudioViewModel

@Composable
fun ControlScreen(initialTab: Int = 0) {
    var tab by remember { mutableStateOf(initialTab) }
    val labels = listOf("Phone", "Command Studio", "Timer")
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Control Center", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Neon)
        TabRow(selectedTabIndex = tab, containerColor = androidx.compose.ui.graphics.Color.Transparent) {
            labels.forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
            }
        }
        Spacer(Modifier.padding(6.dp))
        when (tab) {
            0 -> PhoneTab()
            1 -> StudioTab()
            else -> TimerTab()
        }
    }
}

@Composable
private fun ResultPill(result: ActionResult?) {
    when (result) {
        null -> Unit
        is ActionResult.Success -> StatusPill(result.message, Success)
        is ActionResult.Failure -> StatusPill(result.message, Danger)
    }
}

@Composable
private fun PhoneTab() {
    val vm = shivamViewModel { ControlViewModel(it) }
    val flashOn by vm.flashlightOn.collectAsState()
    val apps by vm.installedApps.collectAsState()
    val result by vm.lastResult.collectAsState()
    var pendingFlash by remember { mutableStateOf<Boolean?>(null) }
    var pendingApp by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard {
            Text("Flashlight", fontWeight = FontWeight.SemiBold)
            Text(
                if (vm.hasFlashlight) "Back camera torch. Changes ask for confirmation." else "No flashlight on this device.",
                color = TextMuted
            )
            if (vm.hasFlashlight) {
                Button(onClick = { pendingFlash = !flashOn }) {
                    Icon(if (flashOn) Icons.Default.FlashlightOff else Icons.Default.FlashlightOn, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (flashOn) "Turn off" else "Turn on")
                }
            }
        }

        GlassCard {
            Text("Open an app", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                label = { Text("App name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            val matches = apps.filter { query.isBlank() || it.contains(query, ignoreCase = true) }.take(6)
            matches.forEach { name ->
                Text(
                    name,
                    modifier = Modifier.fillMaxWidth().clickable { pendingApp = name }.padding(vertical = 8.dp),
                    color = TextMuted
                )
            }
            if (query.isNotBlank() && matches.isEmpty()) {
                Text("No installed app matches. Try a different name.", color = TextMuted)
            }
        }

        GlassCard {
            Text("System settings", fontWeight = FontWeight.SemiBold)
            Text("Opens the panel only. Android does not let apps flip these switches silently.", color = TextMuted)
            SettingsPanel.entries.forEach { panel ->
                OutlinedButton(onClick = { vm.openSettings(panel) }, modifier = Modifier.padding(vertical = 2.dp)) {
                    Text(panel.label)
                }
            }
        }

        ResultPill(result)
    }

    pendingFlash?.let { target ->
        ConfirmDialog(
            title = if (target) "Turn on flashlight?" else "Turn off flashlight?",
            message = "SHIVAM OS will change the back flashlight.",
            confirmLabel = "Confirm",
            onConfirm = { vm.confirmFlashlight(target); pendingFlash = null },
            onDismiss = { pendingFlash = null }
        )
    }
    pendingApp?.let { name ->
        ConfirmDialog(
            title = "Open $name?",
            message = "This launches the app in the foreground.",
            onConfirm = { vm.confirmOpenApp(name); pendingApp = null },
            onDismiss = { pendingApp = null }
        )
    }
}

@Composable
private fun StudioTab() {
    val vm = shivamViewModel { StudioViewModel(it) }
    val routines by vm.routines.collectAsState()
    val lastRun by vm.lastRun.collectAsState()
    var showCreate by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        Text(
            "Routines run when your command contains the trigger phrase. Supported actions: flashlight on/off, open an app, speak text, or ask Optimus.",
            color = TextMuted, style = MaterialTheme.typography.bodySmall
        )
        Button(onClick = { showCreate = true }, modifier = Modifier.padding(vertical = 8.dp)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("New routine")
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (routines.isEmpty()) {
                GlassCard { Text("No routines yet. Tap + to create one, e.g. \"Movie time\" → flashlight off.", color = TextMuted) }
            }
            routines.forEach { RoutineCard(it, vm) }
            if (lastRun.isNotBlank()) StatusPill(lastRun)
        }
    }
    if (showCreate) CreateRoutineDialog(vm, onDismiss = { showCreate = false })
}

@Composable
private fun RoutineCard(routine: RoutineEntity, vm: StudioViewModel) {
    GlassCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(routine.name, fontWeight = FontWeight.SemiBold)
                Text("Say: \"${routine.triggerPhrase}\"", color = TextMuted)
                Text(routine.actionType.replace('_', ' ').lowercase(), color = Neon, style = MaterialTheme.typography.labelMedium)
            }
            Switch(checked = routine.enabled, onCheckedChange = { vm.toggle(routine) },
                colors = SwitchDefaults.colors(checkedTrackColor = Neon))
        }
        Row {
            TextButton(onClick = { vm.test(routine) }) { Text("Test run", color = Neon) }
            TextButton(onClick = { vm.delete(routine) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Danger)
            }
        }
    }
}

@Composable
private fun CreateRoutineDialog(vm: StudioViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var trigger by remember { mutableStateOf("") }
    var action by remember { mutableStateOf(RoutineAction.FLASHLIGHT_ON) }
    var value by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New routine") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(trigger, { trigger = it }, label = { Text("Trigger phrase") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RoutineAction.entries.take(3).forEach { a ->
                        FilterChip(selected = action == a, onClick = { action = a },
                            label = { Text(a.name.replace('_', ' ').lowercase()) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RoutineAction.entries.drop(3).forEach { a ->
                        FilterChip(selected = action == a, onClick = { action = a },
                            label = { Text(a.name.replace('_', ' ').lowercase()) })
                    }
                }
                if (action in setOf(RoutineAction.OPEN_APP, RoutineAction.SPEAK, RoutineAction.ASK_AI)) {
                    OutlinedTextField(value, { value = it },
                        label = { Text(if (action == RoutineAction.OPEN_APP) "App name" else "Text / prompt") })
                }
                error?.let { Text(it, color = Danger) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.save(name, trigger, action, value) { err ->
                    if (err == null) onDismiss() else error = err
                }
            }) { Text("Save", color = Neon) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun TimerTab() {
    val vm = shivamViewModel { ControlViewModel(it) }
    val timer by vm.timer.collectAsState()
    var minutes by remember { mutableStateOf("5") }
    var label by remember { mutableStateOf("Timer") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard {
            Text("Countdown", fontWeight = FontWeight.SemiBold)
            Text("Runs while the app is open and announces the end by voice. Background timers are not included.", color = TextMuted)
            OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit).take(3) },
                label = { Text("Minutes") }, singleLine = true)
            OutlinedTextField(label, { label = it }, label = { Text("Label") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val m = minutes.toIntOrNull()?.coerceIn(1, 600) ?: 5
                    vm.startTimer(m * 60, label.ifBlank { "Timer" })
                }) { Text("Start") }
                OutlinedButton(onClick = vm::cancelTimer) { Text("Cancel") }
            }
        }
        if (timer.running || timer.remainingSeconds > 0) {
            GlassCard {
                Text(timer.label, color = TextMuted)
                Text(
                    String.format("%02d:%02d", timer.remainingSeconds / 60, timer.remainingSeconds % 60),
                    style = MaterialTheme.typography.displayMedium, color = Neon
                )
            }
        }
    }
}
