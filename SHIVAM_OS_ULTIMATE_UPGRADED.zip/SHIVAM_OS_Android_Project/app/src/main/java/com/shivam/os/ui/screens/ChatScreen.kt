package com.shivam.os.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shivam.os.data.MessageEntity
import com.shivam.os.ui.components.AiCore
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.components.StatusPill
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.NeonViolet
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.ChatViewModel

@Composable
fun ChatScreen(onOpenSettings: () -> Unit) {
    val vm = shivamViewModel { ChatViewModel(it) }
    val messages by vm.messages.collectAsState()
    val busy by vm.busy.collectAsState()
    val speak by vm.speakReplies.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AiCore(coreSize = 44.dp, active = busy)
            Column(Modifier.padding(start = 4.dp).weight(1f)) {
                Text("Optimus Core", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                StatusPill(if (busy) "Thinking…" else "Online · Hindi / Hinglish / English")
            }
            IconButton(onClick = vm::toggleSpeakReplies) {
                Icon(
                    if (speak) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = "Speak replies",
                    tint = if (speak) Neon else TextMuted
                )
            }
            IconButton(onClick = vm::clearChat) { Icon(Icons.Default.Delete, "Clear chat", tint = TextMuted) }
            IconButton(onClick = onOpenSettings) { Icon(Icons.Default.Settings, "Settings", tint = TextMuted) }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    GlassCard {
                        Text("Ask me anything, or try a command:", color = TextMuted)
                        Spacer(Modifier.padding(4.dp))
                        Text("• \"Turn on flashlight\"  • \"Open YouTube\"", color = TextMuted)
                        Text("• \"Alarm 6:30 am\"  • \"Note: buy milk\"", color = TextMuted)
                        Text("• \"Remember that my exam is on Monday\"", color = TextMuted)
                        Text("• \"Explain photosynthesis in Hinglish\"", color = TextMuted)
                    }
                }
            }
            items(messages, key = { it.id }) { MessageBubble(it) }
            if (busy) item { CircularProgressIndicator(color = NeonViolet, modifier = Modifier.padding(8.dp)) }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Message Optimus…") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                singleLine = false,
                maxLines = 4,
                keyboardActions = KeyboardActions(onSend = {
                    if (input.isNotBlank()) { vm.send(input); input = "" }
                })
            )
            IconButton(
                onClick = { if (input.isNotBlank()) { vm.send(input); input = "" } },
                enabled = input.isNotBlank() && !busy
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = if (input.isNotBlank()) Neon else TextMuted)
            }
        }
    }
}

@Composable
private fun MessageBubble(message: MessageEntity) {
    val isUser = message.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(if (isUser) Neon.copy(alpha = 0.18f) else androidx.compose.ui.graphics.Color(0x1AFFFFFF))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(message.content, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
