package com.shivam.os.alarm

import java.time.ZonedDateTime

/** Pure next-trigger logic, free of Android types so it can be unit tested on the JVM. */
object AlarmTimeCalculator {

    /** Bit for a java.time day: Sunday -> bit 0 ... Saturday -> bit 6. */
    fun dayBit(now: ZonedDateTime): Int = 1 shl (now.dayOfWeek.value % 7)

    /**
     * Returns the next epoch millis at which an alarm at [hour]:[minute] should fire, strictly after
     * [now]. [repeatMask] = 0 means one-shot (next occurrence of that clock time).
     */
    fun nextTrigger(now: ZonedDateTime, hour: Int, minute: Int, repeatMask: Int): Long {
        require(hour in 0..23 && minute in 0..59) { "Invalid time $hour:$minute" }
        for (offset in 0..7) {
            val candidate = now.toLocalDate().plusDays(offset.toLong()).atTime(hour, minute).atZone(now.zone)
            if (!candidate.isAfter(now)) continue
            if (repeatMask == 0 || (repeatMask and dayBit(candidate)) != 0) {
                return candidate.toInstant().toEpochMilli()
            }
        }
        // Unreachable for valid masks; fall back to tomorrow at the same time.
        return now.toLocalDate().plusDays(1).atTime(hour, minute).atZone(now.zone).toInstant().toEpochMilli()
    }

    fun repeatLabel(mask: Int): String {
        if (mask == 0) return "Once"
        if (mask == 0b1111111) return "Every day"
        if (mask == 0b0111110) return "Weekdays"
        if (mask == 0b1000001) return "Weekends"
        val names = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
        return names.filterIndexed { i, _ -> mask and (1 shl i) != 0 }.joinToString(" ")
    }
}
