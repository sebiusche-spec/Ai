package com.shivam.os.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.StudyMode
import com.shivam.os.viewmodel.StudyViewModel

@Composable
fun StudyScreen() {
    val vm = shivamViewModel { StudyViewModel(it) }
    val notes by vm.notes.collectAsState()
    val output by vm.output.collectAsState()
    val busy by vm.busy.collectAsState()
    var mode by remember { mutableStateOf(StudyMode.EXPLAIN) }
    var input by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("7") }
    var noteTitle by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Study Pilot", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Neon)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            StudyMode.entries.forEach { m ->
                FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label) })
            }
        }
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text(if (mode == StudyMode.SUMMARIZE) "Paste text to summarize" else "Topic or question") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        if (mode == StudyMode.SCHEDULE) {
            OutlinedTextField(
                value = days,
                onValueChange = { days = it.filter(Char::isDigit).take(2) },
                label = { Text("Days") },
                singleLine = true
            )
        }
        Button(
            onClick = { vm.run(mode, input, days.toIntOrNull()?.coerceIn(1, 60) ?: 7) },
            enabled = !busy && input.isNotBlank()
        ) { Text(if (busy) "Working…" else "Run") }

        if (output.isNotBlank()) {
            GlassCard {
                Text(output)
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = noteTitle, onValueChange = { noteTitle = it },
                        label = { Text("Note title") }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(onClick = { vm.saveOutputAsNote(noteTitle); noteTitle = "" }) { Text("Save") }
                }
            }
        }

        Text("Saved notes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (notes.isEmpty()) Text("No saved notes yet.", color = TextMuted)
        notes.forEach { note ->
            GlassCard {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(note.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vm.deleteNote(note) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete note", tint = Danger)
                    }
                }
                Text(note.body.take(300), color = TextMuted)
            }
        }
    }
}
