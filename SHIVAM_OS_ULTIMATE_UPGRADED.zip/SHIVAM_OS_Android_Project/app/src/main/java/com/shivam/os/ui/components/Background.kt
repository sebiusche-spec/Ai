package com.shivam.os.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.NeonViolet

/**
 * Drawn night-sky background in the reference's navy/cyan palette: a vertical gradient, two soft glows,
 * a layered mountain silhouette and a faint lake reflection. Vector drawing only, so it uses no bitmap
 * memory and does not change with frames.
 */
@Composable
fun CinematicBackground(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            Brush.verticalGradient(
                listOf(Color(0xFF02040A), Color(0xFF071230), Color(0xFF0A1B3F), Color(0xFF05070F))
            )
        )
        val glowRadius = size.minDimension * 0.65f
        drawCircle(
            Brush.radialGradient(listOf(Neon.copy(alpha = 0.20f), Color.Transparent), center = Offset(w * 0.5f, h * 0.2f), radius = glowRadius),
            radius = glowRadius, center = Offset(w * 0.5f, h * 0.2f)
        )
        drawCircle(
            Brush.radialGradient(listOf(NeonViolet.copy(alpha = 0.16f), Color.Transparent), center = Offset(w * 0.9f, h * 0.75f), radius = glowRadius),
            radius = glowRadius, center = Offset(w * 0.9f, h * 0.75f)
        )
        val far = Path().apply {
            moveTo(0f, h * 0.70f)
            lineTo(w * 0.15f, h * 0.58f); lineTo(w * 0.30f, h * 0.68f); lineTo(w * 0.50f, h * 0.54f)
            lineTo(w * 0.70f, h * 0.66f); lineTo(w * 0.86f, h * 0.57f); lineTo(w, h * 0.67f)
            lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(far, Color(0xFF0B1B3A).copy(alpha = 0.6f))
        val near = Path().apply {
            moveTo(0f, h * 0.82f)
            lineTo(w * 0.25f, h * 0.74f); lineTo(w * 0.55f, h * 0.80f); lineTo(w * 0.80f, h * 0.73f)
            lineTo(w, h * 0.80f); lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(near, Color(0xFF060F22).copy(alpha = 0.85f))
        drawRect(
            Brush.verticalGradient(listOf(Color.Transparent, Neon.copy(alpha = 0.06f)), startY = h * 0.85f, endY = h),
            topLeft = Offset(0f, h * 0.85f), size = Size(w, h * 0.15f)
        )
    }
}
