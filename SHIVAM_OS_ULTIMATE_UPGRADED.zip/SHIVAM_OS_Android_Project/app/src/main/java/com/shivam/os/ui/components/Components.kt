package com.shivam.os.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.NeonViolet
import com.shivam.os.ui.theme.SurfaceGlass
import com.shivam.os.ui.theme.TextMuted
import kotlin.math.abs
import kotlin.math.sin

/** Glassmorphism card: translucent fill, thin neon border, rounded corners. */
@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(SurfaceGlass)
            .border(1.dp, Neon.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

/** Animated AI core. Rotating arcs and a pulsing centre; reacts to [level] while [active]. */
@Composable
fun AiCore(
    modifier: Modifier = Modifier,
    coreSize: Dp = 180.dp,
    active: Boolean = false,
    level: Float = 0f
) {
    val transition = rememberInfiniteTransition(label = "core")
    val rotation by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (active) 4000 else 12000, easing = LinearEasing)),
        label = "rotation"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "pulse"
    )
    Canvas(modifier.size(coreSize)) {
        val c = center
        val r = size.minDimension / 2f
        val scale = if (active) pulse + level * 0.35f else pulse * 0.95f

        drawCircle(
            brush = Brush.radialGradient(listOf(Neon.copy(alpha = 0.35f), Color.Transparent), center = c, radius = r),
            radius = r, center = c
        )
        rotate(rotation, c) {
            for (i in 0 until 4) {
                drawArc(
                    color = if (i % 2 == 0) Neon else NeonViolet,
                    startAngle = i * 90f,
                    sweepAngle = 60f,
                    useCenter = false,
                    topLeft = Offset(c.x - r * 0.8f, c.y - r * 0.8f),
                    size = Size(r * 1.6f, r * 1.6f),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
        drawCircle(
            brush = Brush.linearGradient(listOf(Neon, NeonViolet)),
            radius = r * 0.32f * scale,
            center = c
        )
    }
}

/** Animated waveform bars. Amplitude follows microphone [level]; flat when inactive. */
@Composable
fun Waveform(modifier: Modifier = Modifier, active: Boolean, level: Float) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 6.28f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "phase"
    )
    Canvas(modifier.fillMaxWidth().height(72.dp)) {
        val bars = 28
        val gap = 4.dp.toPx()
        val barW = (size.width - gap * (bars - 1)) / bars
        val mid = size.height / 2f
        for (i in 0 until bars) {
            val wobble = abs(sin(phase + i * 0.55f))
            val amp = if (active) 0.2f + 0.8f * (0.35f + level) * wobble else 0.08f
            val h = (size.height * amp).coerceAtLeast(4.dp.toPx())
            val x = i * (barW + gap)
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Neon, NeonViolet)),
                topLeft = Offset(x, mid - h / 2f),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f)
            )
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String = "Confirm",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message, color = TextMuted) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmLabel, color = Neon) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun StatusPill(text: String, color: Color = Neon) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = color)
    }
}
