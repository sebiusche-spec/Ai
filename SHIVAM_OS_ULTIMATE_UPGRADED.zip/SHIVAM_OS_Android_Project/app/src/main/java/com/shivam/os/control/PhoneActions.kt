package com.shivam.os.control

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.Settings

/** Outcome of a device action, shown to the user. Unsupported features return Failure, never fake success. */
sealed interface ActionResult {
    data class Success(val message: String) : ActionResult
    data class Failure(val message: String) : ActionResult
}

/**
 * Phone actions that Android allows an ordinary app to perform. Note: Android does not let apps
 * toggle Wi-Fi, Bluetooth or mobile data silently, so those open the relevant Settings panel instead.
 */
object PhoneActions {

    private var torchOn = false

    fun setFlashlight(context: Context, on: Boolean): ActionResult {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = try {
            cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) ==
                    CameraCharacteristics.LENS_FACING_BACK
            } ?: return ActionResult.Failure("This device has no back flashlight available.")
        } catch (e: CameraAccessException) {
            return ActionResult.Failure("Camera is busy or blocked. Close other camera apps and try again.")
        }
        return try {
            cm.setTorchMode(cameraId, on)
            torchOn = on
            ActionResult.Success(if (on) "Flashlight on." else "Flashlight off.")
        } catch (e: CameraAccessException) {
            ActionResult.Failure("Could not change the flashlight: camera is in use.")
        } catch (e: IllegalArgumentException) {
            ActionResult.Failure("Flashlight is not supported on this device.")
        }
    }

    fun isTorchOn(): Boolean = torchOn

    /** Finds an installed launchable app whose label matches [query] (exact match preferred). */
    fun openApp(context: Context, query: String): ActionResult {
        val pm = context.packageManager
        val launchable = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val q = query.trim().lowercase()
        if (q.isEmpty()) return ActionResult.Failure("Tell me which app to open.")

        val match = launchable.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: launchable.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return ActionResult.Failure("No installed app matches \"$query\".")

        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return ActionResult.Failure("${match.loadLabel(pm)} cannot be launched.")
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(launch)
            ActionResult.Success("Opening ${match.loadLabel(pm)}.")
        } catch (e: Exception) {
            ActionResult.Failure("Could not open ${match.loadLabel(pm)}.")
        }
    }

    /** Opens a Settings panel. Only panels that exist on this device are offered. */
    fun openSettings(context: Context, panel: SettingsPanel): ActionResult {
        val intent = Intent(panel.action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(context.packageManager) == null) {
            return ActionResult.Failure("${panel.label} is not available on this device.")
        }
        context.startActivity(intent)
        return ActionResult.Success("Opening ${panel.label}.")
    }

    fun hasFlashlight(context: Context): Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
}

enum class SettingsPanel(val label: String, val action: String) {
    SETTINGS("Settings", Settings.ACTION_SETTINGS),
    WIFI("Wi-Fi settings", Settings.ACTION_WIFI_SETTINGS),
    BLUETOOTH("Bluetooth settings", Settings.ACTION_BLUETOOTH_SETTINGS),
    DISPLAY("Display settings", Settings.ACTION_DISPLAY_SETTINGS),
    SOUND("Sound settings", Settings.ACTION_SOUND_SETTINGS),
    APPS("App settings", Settings.ACTION_APPLICATION_SETTINGS),
    NOTIFICATIONS("Notification settings", Settings.ACTION_ALL_APPS_NOTIFICATION_SETTINGS),
    EXACT_ALARMS("Exact alarm access", Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
}
