package com.shivam.os.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Background = Color(0xFF05070F)
val Surface = Color(0xFF0C1020)
val SurfaceGlass = Color(0x1AFFFFFF)
val Neon = Color(0xFF00E5FF)      // cyan
val NeonViolet = Color(0xFF8B5CF6)
val TextPrimary = Color(0xFFE8F4FF)
val TextMuted = Color(0xFF8A93A8)
val Danger = Color(0xFFFF5C7A)
val Success = Color(0xFF3DFFB0)

val NeonGradient = Brush.horizontalGradient(listOf(Neon, NeonViolet))

private val ShivamColors = darkColorScheme(
    primary = Neon,
    onPrimary = Background,
    secondary = NeonViolet,
    onSecondary = Color.White,
    background = Background,
    onBackground = TextPrimary,
    surface = Surface,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFF141A2E),
    onSurfaceVariant = TextMuted,
    error = Danger,
    outline = Color(0x3300E5FF)
)

@Composable
fun ShivamTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ShivamColors, typography = MaterialTheme.typography, content = content)
}
