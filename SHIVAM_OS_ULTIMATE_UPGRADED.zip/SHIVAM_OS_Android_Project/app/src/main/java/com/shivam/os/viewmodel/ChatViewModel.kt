package com.shivam.os.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.shivam.os.data.MessageEntity

class ChatViewModel(private val app: ShivamApp) : ViewModel() {

    val messages: StateFlow<List<MessageEntity>> = app.chat.messages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _speakReplies = MutableStateFlow(false)
    val speakReplies: StateFlow<Boolean> = _speakReplies.asStateFlow()

    fun send(text: String) {
        if (text.isBlank() || _busy.value) return
        viewModelScope.launch {
            _busy.value = true
            try {
                val reply = app.assistant.handle(text)
                if (_speakReplies.value && !reply.isError) {
                    val s = app.settings
                    app.speaker.speak(
                        reply.text,
                        language = s.ttsLanguage.first(),
                        speed = s.ttsSpeed.first(),
                        pitch = s.ttsPitch.first()
                    )
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun toggleSpeakReplies() { _speakReplies.value = !_speakReplies.value }

    fun clearChat() {
        viewModelScope.launch { app.db.messageDao().clear() }
    }
}
