package com.shivam.os.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shivam.os.data.GalleryItemEntity
import com.shivam.os.ui.components.ConfirmDialog
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.GalleryViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun GalleryScreen() {
    val vm = shivamViewModel { GalleryViewModel(it) }
    val items by vm.items.collectAsState()
    var toRemove by remember { mutableStateOf<GalleryItemEntity?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(maxItems = 20)) { uris ->
        vm.addPicked(uris)
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Gallery", style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold, color = Neon, modifier = Modifier.weight(1f)
            )
            Button(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Add photos")
            }
        }
        Text(
            "Photos come from Android's photo picker. SHIVAM OS does not scan or upload your library. " +
                "Removing a photo here does not delete it from your device.",
            style = MaterialTheme.typography.labelSmall, color = TextMuted
        )
        if (items.isEmpty()) {
            GlassCard { Text("No photos added yet. Tap Add photos to choose some.", color = TextMuted) }
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(110.dp),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(items, key = { it.id }) { item ->
                Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(14.dp)).background(Color(0x1AFFFFFF))) {
                    Thumbnail(uri = item.uri, modifier = Modifier.fillMaxSize())
                    IconButton(
                        onClick = { toRemove = item },
                        modifier = Modifier.align(Alignment.TopEnd)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Remove from gallery", tint = Color.White)
                    }
                }
            }
        }
    }

    toRemove?.let { item ->
        ConfirmDialog(
            title = "Remove photo?",
            message = "It will be removed from SHIVAM OS. The photo stays on your device.",
            confirmLabel = "Remove",
            onConfirm = { vm.remove(item); toRemove = null },
            onDismiss = { toRemove = null }
        )
    }
}

/** Decodes a sampled bitmap off the main thread. Shows a placeholder while loading and on failure. */
@Composable
private fun Thumbnail(uri: String, modifier: Modifier) {
    val context = LocalContext.current
    val state by produceState<Pair<Boolean, ImageBitmap?>>(initialValue = false to null, key1 = uri) {
        val bmp = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(Uri.parse(uri))?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = 4 })
                }
            }.getOrNull()?.asImageBitmap()
        }
        value = true to bmp
    }
    val (done, bitmap) = state
    when {
        bitmap != null -> Image(bitmap = bitmap, contentDescription = "Photo", contentScale = ContentScale.Crop, modifier = modifier)
        done -> Box(modifier, contentAlignment = Alignment.Center) {
            Text("Unavailable", style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
        else -> Box(modifier, contentAlignment = Alignment.Center) {
            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        }
    }
}
