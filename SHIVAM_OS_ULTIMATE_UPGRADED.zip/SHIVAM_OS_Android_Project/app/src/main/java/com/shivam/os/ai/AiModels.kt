package com.shivam.os.ai

enum class ProviderType(val label: String, val defaultBaseUrl: String, val defaultModel: String) {
    OPENAI_COMPATIBLE(
        "OpenAI-compatible (OpenAI, OpenRouter, Groq, Together, Ollama, LM Studio, ...)",
        "https://api.openai.com/v1",
        "gpt-4o-mini"
    ),
    ANTHROPIC(
        "Anthropic Messages API",
        "https://api.anthropic.com",
        "claude-3-5-haiku-latest"
    )
}

data class AiConfig(
    val provider: ProviderType = ProviderType.OPENAI_COMPATIBLE,
    val baseUrl: String = ProviderType.OPENAI_COMPATIBLE.defaultBaseUrl,
    val model: String = ProviderType.OPENAI_COMPATIBLE.defaultModel,
    val apiKey: String = ""
) {
    /** Returns a user-facing problem with this configuration, or null if it looks usable. */
    fun validationError(): String? = when {
        apiKey.isBlank() -> "API key is missing. Add it in Settings → AI Provider."
        model.isBlank() -> "Model name is empty. Enter a model name such as ${provider.defaultModel}."
        ApiUrls.validateBaseUrl(baseUrl) != null -> ApiUrls.validateBaseUrl(baseUrl)
        else -> null
    }
}

data class ChatTurn(val role: String, val content: String)

sealed interface AiResult {
    data class Ok(val text: String) : AiResult
    data class Error(val message: String) : AiResult
}
