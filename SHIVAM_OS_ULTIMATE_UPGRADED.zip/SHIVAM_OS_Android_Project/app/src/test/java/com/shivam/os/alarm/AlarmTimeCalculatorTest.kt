package com.shivam.os.alarm

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class AlarmTimeCalculatorTest {

    private val zone = ZoneId.of("Asia/Kolkata")
    // Thursday 22 Oct 2026, 10:00 local.
    private val now = ZonedDateTime.of(2026, 10, 22, 10, 0, 0, 0, zone)

    private fun at(y: Int, mo: Int, d: Int, h: Int, mi: Int) =
        ZonedDateTime.of(y, mo, d, h, mi, 0, 0, zone).toInstant().toEpochMilli()

    @Test
    fun oneShot_laterToday_firesToday() {
        assertEquals(at(2026, 10, 22, 18, 30), AlarmTimeCalculator.nextTrigger(now, 18, 30, 0))
    }

    @Test
    fun oneShot_alreadyPassed_firesTomorrow() {
        assertEquals(at(2026, 10, 23, 7, 0), AlarmTimeCalculator.nextTrigger(now, 7, 0, 0))
    }

    @Test
    fun repeating_weekdays_fromThursdayMorningAfterAlarm_firesFriday() {
        val weekdays = 0b0111110 // Mon-Fri
        assertEquals(at(2026, 10, 23, 9, 0), AlarmTimeCalculator.nextTrigger(now, 9, 0, weekdays))
    }

    @Test
    fun repeating_weekend_fromFriday_skipsToSaturday() {
        val weekends = 0b1000001 // Sun + Sat
        val friday = ZonedDateTime.of(2026, 10, 23, 12, 0, 0, 0, zone)
        assertEquals(at(2026, 10, 24, 8, 0), AlarmTimeCalculator.nextTrigger(friday, 8, 0, weekends))
    }

    @Test
    fun dayBit_sundayIsBitZero() {
        val sunday = ZonedDateTime.of(2026, 10, 25, 0, 0, 0, 0, zone)
        assertEquals(1, AlarmTimeCalculator.dayBit(sunday))
    }

    @Test
    fun repeatLabel_namesCommonPatterns() {
        assertEquals("Once", AlarmTimeCalculator.repeatLabel(0))
        assertEquals("Every day", AlarmTimeCalculator.repeatLabel(0b1111111))
        assertEquals("Weekdays", AlarmTimeCalculator.repeatLabel(0b0111110))
    }
}
