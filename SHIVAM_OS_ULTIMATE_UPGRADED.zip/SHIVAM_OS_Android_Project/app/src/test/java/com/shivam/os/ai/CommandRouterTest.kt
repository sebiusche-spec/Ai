package com.shivam.os.ai

import org.junit.Assert.assertEquals
import org.junit.Test

class CommandRouterTest {

    @Test
    fun flashlight_onAndOff_detected() {
        assertEquals(Intent.FlashlightOn, CommandRouter.parse("turn on the flashlight"))
        assertEquals(Intent.FlashlightOff, CommandRouter.parse("flashlight band karo"))
        assertEquals(Intent.FlashlightOn, CommandRouter.parse("torch chalu karo"))
    }

    @Test
    fun flashlight_wordsInsideOtherWords_areNotMatched() {
        assertEquals(Intent.ToAi, CommandRouter.parse("what is the phone battery"))
    }

    @Test
    fun openApp_extractsName() {
        assertEquals(Intent.OpenApp("YouTube"), CommandRouter.parse("Open YouTube"))
        assertEquals(Intent.OpenApp("WhatsApp"), CommandRouter.parse("kholo WhatsApp"))
    }

    @Test
    fun alarm_parsesTimeAndMeridiem() {
        val a = CommandRouter.parse("set alarm for 6:30 pm") as Intent.SetAlarm
        assertEquals(18, a.hour)
        assertEquals(30, a.minute)
        val b = CommandRouter.parse("alarm 7 am") as Intent.SetAlarm
        assertEquals(7, b.hour)
    }

    @Test
    fun confirmAndCancel_recognisedInHinglish() {
        assertEquals(Intent.Confirm, CommandRouter.parse("haan"))
        assertEquals(Intent.Cancel, CommandRouter.parse("nahi"))
        assertEquals(Intent.Confirm, CommandRouter.parse("yes"))
    }

    @Test
    fun remember_keepsOriginalCase() {
        val r = CommandRouter.parse("Remember that my Exam is on Monday") as Intent.RememberFact
        assertEquals("my Exam is on Monday", r.fact)
    }

    @Test
    fun unknownText_goesToAi() {
        assertEquals(Intent.ToAi, CommandRouter.parse("explain photosynthesis"))
        assertEquals(Intent.ToAi, CommandRouter.parse(""))
    }
}

class CommandRouterUpgradeTest {
    @Test
    fun batteryTimeAndSettings_areRecognised() {
        assertEquals(Intent.Battery, CommandRouter.parse("Battery kitni hai?"))
        assertEquals(Intent.TimeNow, CommandRouter.parse("Jarvis, time kya hua hai?"))
        assertEquals(Intent.OpenSettings, CommandRouter.parse("Settings kholo"))
        assertEquals(Intent.OpenSettings, CommandRouter.parse("open settings"))
    }
}
