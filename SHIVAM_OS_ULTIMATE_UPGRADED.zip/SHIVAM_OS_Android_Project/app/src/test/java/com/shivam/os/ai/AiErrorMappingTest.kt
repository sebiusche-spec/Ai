package com.shivam.os.ai

import org.junit.Assert.assertTrue
import org.junit.Test

class AiErrorMappingTest {

    @Test
    fun unauthorized_mentionsKey() {
        assertTrue(AiClient.mapHttpError(401, "").contains("Invalid API key"))
    }

    @Test
    fun notFound_mentionsModelOrEndpoint() {
        assertTrue(AiClient.mapHttpError(404, "").contains("model"))
    }

    @Test
    fun rateLimit_isExplained() {
        assertTrue(AiClient.mapHttpError(429, "").contains("Rate limit"))
    }

    @Test
    fun serverError_isExplained() {
        assertTrue(AiClient.mapHttpError(503, "").contains("server error"))
    }
}
