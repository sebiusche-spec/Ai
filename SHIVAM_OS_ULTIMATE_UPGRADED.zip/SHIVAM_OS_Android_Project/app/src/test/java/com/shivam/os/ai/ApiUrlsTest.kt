package com.shivam.os.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class ApiUrlsTest {

    @Test
    fun openAi_appendsChatCompletions() {
        assertEquals("https://api.openai.com/v1/chat/completions",
            ApiUrls.openAiChatCompletions("https://api.openai.com/v1"))
    }

    @Test
    fun openAi_trailingSlashAndFullUrlAreNormalised() {
        assertEquals("https://host/v1/chat/completions", ApiUrls.openAiChatCompletions("https://host/v1/"))
        assertEquals("https://host/v1/chat/completions", ApiUrls.openAiChatCompletions("https://host/v1/chat/completions"))
    }

    @Test
    fun anthropic_handlesBareHostAndVersionedBase() {
        assertEquals("https://api.anthropic.com/v1/messages", ApiUrls.anthropicMessages("https://api.anthropic.com"))
        assertEquals("https://api.anthropic.com/v1/messages", ApiUrls.anthropicMessages("https://api.anthropic.com/v1"))
        assertEquals("https://api.anthropic.com/v1/messages", ApiUrls.anthropicMessages("https://api.anthropic.com/v1/messages"))
    }

    @Test
    fun validateBaseUrl_rejectsBadInput() {
        assertNotNull(ApiUrls.validateBaseUrl(""))
        assertNotNull(ApiUrls.validateBaseUrl("api.openai.com/v1"))
        assertNotNull(ApiUrls.validateBaseUrl("https://bad host"))
        assertNull(ApiUrls.validateBaseUrl("http://localhost:11434/v1"))
    }

    @Test
    fun config_withoutKey_reportsMissingKey() {
        assertNotNull(AiConfig(apiKey = "").validationError())
    }
}
