# Room, OkHttp and Compose ship their own consumer rules.
# Keep receivers referenced from the manifest.
-keep class com.shivam.os.alarm.** { *; }
