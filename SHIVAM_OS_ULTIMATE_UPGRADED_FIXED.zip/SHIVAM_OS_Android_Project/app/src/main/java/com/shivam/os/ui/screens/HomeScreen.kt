package com.shivam.os.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.shivam.os.ui.components.AiCore
import com.shivam.os.ui.components.GlassCard
import com.shivam.os.ui.components.StatusPill
import com.shivam.os.ui.theme.Danger
import com.shivam.os.ui.theme.Neon
import com.shivam.os.ui.theme.Success
import com.shivam.os.ui.theme.TextMuted
import com.shivam.os.util.shivamViewModel
import com.shivam.os.viewmodel.AlarmUi
import com.shivam.os.viewmodel.HomeViewModel
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(onNavigate: (String) -> Unit) {
    val vm = shivamViewModel { HomeViewModel(it) }
    val context = LocalContext.current
    val now by vm.now.collectAsState()
    val battery by vm.battery.collectAsState()
    val network by vm.network.collectAsState()
    val aiStatus by vm.aiStatus.collectAsState()
    val running by vm.serviceRunning.collectAsState()
    val serviceError by vm.serviceError.collectAsState()
    val alarms by vm.upcomingAlarms.collectAsState()
    val recent by vm.recentCommands.collectAsState()
    val reply by vm.lastReply.collectAsState()
    val busy by vm.busy.collectAsState()
    var query by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startAssistant()
        else notice = "Notifications are off. Allow them to see the assistant's Stop notification. The assistant was not started."
    }

    // The service must show a notification, so it never starts without notification permission.
    val startAssistant: () -> Unit = {
        val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        notice = ""
        if (needsPermission) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.startAssistant()
    }

    fun openExternal(intent: android.content.Intent, missingMessage: String) {
        if (!vm.openIntent(context, intent)) notice = missingMessage
    }

    val sendQuery: () -> Unit = {
        if (query.isNotBlank()) {
            vm.send(query)
            query = ""
        }
    }

    @Composable
    fun Center() {
        val batteryText = when {
            battery.percent < 0 -> "Battery unknown"
            battery.charging -> "Battery ${battery.percent}% · charging"
            else -> "Battery ${battery.percent}%"
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(
                    now.format(DateTimeFormatter.ofPattern("hh:mm a", Locale.getDefault())),
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.Light
                )
                Text(
                    now.format(DateTimeFormatter.ofPattern("EEE, dd MMM yyyy", Locale.getDefault())),
                    color = TextMuted
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                StatusPill(batteryText, if (battery.charging) Success else Neon)
                Spacer(Modifier.height(6.dp))
                StatusPill("Network: $network")
            }
        }

        Text(
            "Hey ${vm.name}, kya karna hai?",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold
        )

        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            AiCore(coreSize = 150.dp, active = busy || running)
        }
        val statusLine = when {
            busy -> "Processing your command…"
            running -> "Assistant is active. Use the notification or Stop to end it."
            else -> "Assistant is stopped. Start it, or type a command below."
        }
        Text(statusLine, color = TextMuted, style = MaterialTheme.typography.bodyMedium)

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (running) {
                Button(onClick = vm::stopAssistant) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Stop assistant")
                }
            } else {
                Button(onClick = startAssistant) {
                    Icon(Icons.Default.Mic, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Start assistant")
                }
            }
            OutlinedButton(onClick = { onNavigate("jarvis") }) { Text("Voice / Chat") }
        }
        if (notice.isNotBlank()) StatusPill(notice, Danger)
        if (serviceError.isNotBlank()) StatusPill(serviceError, Danger)

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            placeholder = { Text("Jarvis se poochho… e.g. battery kitni hai?") },
            leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Neon) },
            trailingIcon = {
                Row {
                    IconButton(onClick = sendQuery, enabled = query.isNotBlank() && !busy) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send command")
                    }
                    IconButton(onClick = { onNavigate("jarvis") }) {
                        Icon(Icons.Default.Mic, contentDescription = "Open voice assistant")
                    }
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { sendQuery() })
        )

        if (reply.isNotBlank()) {
            GlassCard {
                Text("Jarvis", style = MaterialTheme.typography.labelMedium, color = Neon)
                Text(reply)
            }
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ShortcutTile("Apps", Icons.Default.Apps) { onNavigate("control") }
            ShortcutTile("Settings", Icons.Default.Settings) { onNavigate("settings") }
            ShortcutTile("Gallery", Icons.Default.Image) { onNavigate("gallery") }
            ShortcutTile("Browser", Icons.Default.Public) {
                openExternal(vm.browserIntent(), "No browser app is available on this device.")
            }
            ShortcutTile("AI Tools", Icons.Default.AutoAwesome) { onNavigate("study") }
            ShortcutTile("More", Icons.Default.MoreHoriz) { onNavigate("tools") }
        }
    }

    @Composable
    fun Right() {
        GlassCard {
            Text("Next alarm", style = MaterialTheme.typography.labelMedium, color = Neon)
            if (alarms.isEmpty()) {
                Text("No alarms yet.", color = TextMuted)
            } else {
                val next: AlarmUi = alarms.first()
                Text(next.alarm.label, fontWeight = FontWeight.SemiBold)
                Text(formatAlarmTime(next.nextMillis), style = MaterialTheme.typography.titleMedium)
                Text(formatCountdown(next.nextMillis - now.toInstant().toEpochMilli()), color = TextMuted)
                alarms.drop(1).take(2).forEach { ui ->
                    Text("${formatAlarmTime(ui.nextMillis)} · ${ui.alarm.label}", color = TextMuted,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            OutlinedButton(onClick = { onNavigate("alarms") }) {
                Icon(Icons.Default.Alarm, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Open alarms")
            }
        }

        GlassCard {
            Text("Quick actions", style = MaterialTheme.typography.labelMedium, color = Neon)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickTile("Open app", Modifier.weight(1f)) { onNavigate("control") }
                QuickTile("Take photo", Modifier.weight(1f)) {
                    openExternal(android.content.Intent(MediaStore.ACTION_IMAGE_CAPTURE), "No camera app is available.")
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickTile("New alarm", Modifier.weight(1f)) { onNavigate("alarms") }
                QuickTile("New note", Modifier.weight(1f)) { onNavigate("notes") }
            }
        }

        GlassCard {
            Text("System", style = MaterialTheme.typography.labelMedium, color = Neon)
            Text("Battery ${if (battery.percent >= 0) "${battery.percent}%" else "unknown"}")
            LinearProgressIndicator(
                progress = { if (battery.percent >= 0) battery.percent / 100f else 0f },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Network: $network", color = TextMuted)
            Text("AI provider: $aiStatus", color = TextMuted)
            Text("Assistant: ${if (running) "running" else "stopped"}", color = TextMuted)
        }

        GlassCard {
            Text("Recent commands", style = MaterialTheme.typography.labelMedium, color = Neon)
            if (recent.isEmpty()) {
                Text("No commands yet. Try \"Battery kitni hai?\" or \"5 minute ka timer lagao\".", color = TextMuted)
            } else {
                recent.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().padding(16.dp)) {
        if (maxWidth >= 720.dp) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(
                    Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) { Center() }
                Column(
                    Modifier.width(300.dp).fillMaxHeight().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) { Right() }
            }
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Center()
                Right()
            }
        }
    }
}

@Composable
private fun ShortcutTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(com.shivam.os.ui.theme.SurfaceGlass)
            .border(1.dp, Neon.copy(alpha = 0.25f), RoundedCornerShape(18.dp))
            .clickable(onClickLabel = label, role = Role.Button, onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = Neon)
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun QuickTile(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(com.shivam.os.ui.theme.SurfaceGlass)
            .border(1.dp, Neon.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .clickable(onClickLabel = label, role = Role.Button, onClick = onClick)
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = Neon)
    }
}

private fun formatAlarmTime(epochMillis: Long): String =
    Instant.ofEpochMilli(epochMillis).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("EEE h:mm a", Locale.getDefault()))

private fun formatCountdown(remainingMs: Long): String {
    if (remainingMs <= 0) return "due now"
    val totalMinutes = remainingMs / 60_000
    val hours = totalMinutes / 60
    val minutes = totalMinutes % 60
    return if (hours > 0) "in ${hours}h ${minutes}m" else "in ${minutes}m"
}
