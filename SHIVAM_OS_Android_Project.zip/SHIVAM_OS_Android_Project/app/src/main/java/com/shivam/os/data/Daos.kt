package com.shivam.os.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Insert suspend fun insert(message: MessageEntity): Long

    @Query("SELECT * FROM messages ORDER BY createdAt ASC, id ASC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :limit")
    suspend fun latest(limit: Int): List<MessageEntity>

    @Query("DELETE FROM messages")
    suspend fun clear()
}

@Dao
interface AlarmDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(alarm: AlarmEntity): Long
    @Update suspend fun update(alarm: AlarmEntity)
    @Delete suspend fun delete(alarm: AlarmEntity)

    @Query("SELECT * FROM alarms ORDER BY hour, minute")
    fun observeAll(): Flow<List<AlarmEntity>>

    @Query("SELECT * FROM alarms WHERE enabled = 1")
    suspend fun enabled(): List<AlarmEntity>

    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun byId(id: Int): AlarmEntity?

    @Query("DELETE FROM alarms")
    suspend fun clear()
}

@Dao
interface NoteDao {
    @Insert suspend fun insert(note: NoteEntity): Long
    @Delete suspend fun delete(note: NoteEntity)

    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Query("DELETE FROM notes")
    suspend fun clear()
}

@Dao
interface MemoryDao {
    @Insert suspend fun insert(memory: MemoryEntity): Long
    @Delete suspend fun delete(memory: MemoryEntity)

    @Query("SELECT * FROM memories ORDER BY createdAt ASC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY createdAt ASC")
    suspend fun all(): List<MemoryEntity>

    @Query("DELETE FROM memories")
    suspend fun clear()
}

@Dao
interface RoutineDao {
    @Insert suspend fun insert(routine: RoutineEntity): Long
    @Update suspend fun update(routine: RoutineEntity)
    @Delete suspend fun delete(routine: RoutineEntity)

    @Query("SELECT * FROM routines ORDER BY name")
    fun observeAll(): Flow<List<RoutineEntity>>

    @Query("SELECT * FROM routines WHERE enabled = 1")
    suspend fun enabled(): List<RoutineEntity>

    @Query("DELETE FROM routines")
    suspend fun clear()
}
