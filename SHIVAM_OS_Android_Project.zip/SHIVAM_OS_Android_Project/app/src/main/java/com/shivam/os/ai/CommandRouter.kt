package com.shivam.os.ai

/**
 * Local intent router for direct device commands. This is deterministic "tool calling" for a small
 * set of actions. Anything it does not recognise is forwarded to the AI provider.
 */
sealed interface Intent {
    data object FlashlightOn : Intent
    data object FlashlightOff : Intent
    data class OpenApp(val appName: String) : Intent
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : Intent
    data class SaveNote(val text: String) : Intent
    data class RememberFact(val fact: String) : Intent
    data object Confirm : Intent
    data object Cancel : Intent
    data object ToAi : Intent
}

object CommandRouter {

    private val confirmWords = setOf("yes", "y", "haan", "ha", "confirm", "ok", "kar do", "karo")
    private val cancelWords = setOf("no", "n", "nahi", "cancel", "mat karo", "rehne do")

    private val flashWords = Regex("\\b(flashlight|torch)\\b|टॉर्च", RegexOption.IGNORE_CASE)
    private val offWords = Regex("\\b(off|band|bujhao|bujha)\\b", RegexOption.IGNORE_CASE)
    private val onWords = Regex("\\b(on|chalu|jalao|jala)\\b", RegexOption.IGNORE_CASE)
    private val openRegex = Regex("^(?:open|launch|kholo|khol do|start)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val alarmRegex = Regex(
        "\\b(alarm|jagao|jaga do|wake me)\\b.*?(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje)?",
        RegexOption.IGNORE_CASE
    )
    private val rememberRegex = Regex("^(?:remember|yaad rakho|yaad rakhna)(?:\\s+that)?\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val noteRegex = Regex("^(?:note|note down|note likho)[:\\s]+(.+)$", RegexOption.IGNORE_CASE)

    fun parse(input: String): Intent {
        val raw = input.trim()
        val text = raw.lowercase()
        if (text.isEmpty()) return Intent.ToAi
        if (text in confirmWords) return Intent.Confirm
        if (text in cancelWords) return Intent.Cancel

        if (flashWords.containsMatchIn(raw)) {
            if (offWords.containsMatchIn(raw)) return Intent.FlashlightOff
            if (onWords.containsMatchIn(raw)) return Intent.FlashlightOn
        }

        openRegex.matchEntire(raw)?.let { m ->
            val app = m.groupValues[1].replace(Regex(" app$", RegexOption.IGNORE_CASE), "").trim()
            if (app.isNotEmpty()) return Intent.OpenApp(app)
        }

        alarmRegex.find(raw)?.let { m ->
            var hour = m.groupValues[2].toIntOrNull() ?: return@let
            val minute = m.groupValues[3].toIntOrNull() ?: 0
            val meridiem = m.groupValues[4].lowercase()
            if (meridiem == "pm" && hour < 12) hour += 12
            if (meridiem == "am" && hour == 12) hour = 0
            if (hour in 0..23 && minute in 0..59) {
                return Intent.SetAlarm(hour, minute, "Voice alarm")
            }
        }

        rememberRegex.matchEntire(raw)?.let { m -> return Intent.RememberFact(m.groupValues[1].trim()) }
        noteRegex.matchEntire(raw)?.let { m -> return Intent.SaveNote(m.groupValues[1].trim()) }

        return Intent.ToAi
    }
}
