package com.shivam.os.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shivam.os.ui.screens.AlarmScreen
import com.shivam.os.ui.screens.ChatScreen
import com.shivam.os.ui.screens.ControlScreen
import com.shivam.os.ui.screens.SettingsScreen
import com.shivam.os.ui.screens.StudyScreen
import com.shivam.os.ui.screens.VoiceScreen
import com.shivam.os.ui.theme.Background
import com.shivam.os.ui.theme.Neon

enum class AppTab(val route: String, val label: String, val icon: ImageVector) {
    CHAT("chat", "Optimus", Icons.Default.AutoAwesome),
    VOICE("voice", "JARVIS", Icons.Default.Mic),
    ALARMS("alarms", "Chronexa", Icons.Default.Alarm),
    CONTROL("control", "Control", Icons.Default.Tune),
    STUDY("study", "Study", Icons.Default.School)
}

const val SETTINGS_ROUTE = "settings"

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentDest = backStack?.destination
    val showBottomBar = AppTab.entries.any { tab -> currentDest?.hierarchy?.any { it.route == tab.route } == true }

    Scaffold(
        containerColor = Background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = Background.copy(alpha = 0.92f)) {
                    AppTab.entries.forEach { tab ->
                        val selected = currentDest?.hierarchy?.any { it.route == tab.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { androidx.compose.material3.Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Neon,
                                selectedTextColor = Neon,
                                indicatorColor = Neon.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = AppTab.CHAT.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(AppTab.CHAT.route) { ChatScreen(onOpenSettings = { nav.navigate(SETTINGS_ROUTE) }) }
            composable(AppTab.VOICE.route) { VoiceScreen() }
            composable(AppTab.ALARMS.route) { AlarmScreen() }
            composable(AppTab.CONTROL.route) { ControlScreen() }
            composable(AppTab.STUDY.route) { StudyScreen() }
            composable(SETTINGS_ROUTE) { SettingsScreen(onBack = { nav.popBackStack() }) }
        }
    }
}
