package com.shivam.os.viewmodel

import android.content.Context
import com.shivam.os.ai.AiResult
import com.shivam.os.ai.ChatRepository
import com.shivam.os.ai.CommandRouter
import com.shivam.os.ai.Intent
import com.shivam.os.alarm.AlarmScheduler
import com.shivam.os.control.ActionResult
import com.shivam.os.control.PhoneActions
import com.shivam.os.data.AlarmEntity
import com.shivam.os.data.AppDatabase
import com.shivam.os.data.MemoryEntity
import com.shivam.os.data.NoteEntity
import com.shivam.os.data.RoutineEntity
import com.shivam.os.data.SettingsStore
import kotlinx.coroutines.flow.first

data class Reply(val text: String, val isError: Boolean = false)

/** Command Studio actions. Routines are created by the user, so they run without a second confirmation. */
enum class RoutineAction { FLASHLIGHT_ON, FLASHLIGHT_OFF, OPEN_APP, SPEAK, ASK_AI }

/**
 * Single entry point for every input (typed chat, voice, routines). Device actions that change
 * system state are held as a pending request until the user says "yes" or "no".
 */
class AssistantCore(
    private val context: Context,
    private val db: AppDatabase,
    private val chat: ChatRepository,
    private val settings: SettingsStore,
    private val alarms: AlarmScheduler
) {
    private class Pending(val prompt: String, val run: () -> ActionResult)
    private var pending: Pending? = null

    suspend fun handle(input: String): Reply {
        val text = input.trim()
        if (text.isEmpty()) return Reply("Please type or say a command.", isError = true)

        val intent = CommandRouter.parse(text)

        pending?.let { p ->
            pending = null
            when (intent) {
                Intent.Confirm -> return record(text, fromResult(p.run()))
                Intent.Cancel -> return record(text, Reply("Cancelled."))
                else -> Unit // A new request replaces the unconfirmed one.
            }
        }

        return when (intent) {
            Intent.FlashlightOn -> askConfirm(text, "turn on the flashlight") { PhoneActions.setFlashlight(context, true) }
            Intent.FlashlightOff -> askConfirm(text, "turn off the flashlight") { PhoneActions.setFlashlight(context, false) }
            is Intent.OpenApp -> askConfirm(text, "open ${intent.appName}") { PhoneActions.openApp(context, intent.appName) }
            is Intent.SetAlarm -> record(text, setAlarm(intent))
            is Intent.SaveNote -> {
                db.noteDao().insert(NoteEntity(title = intent.text.take(40), body = intent.text))
                record(text, Reply("Saved to your notes."))
            }
            is Intent.RememberFact -> {
                val reply = if (settings.memoryEnabled.first()) {
                    db.memoryDao().insert(MemoryEntity(fact = intent.fact))
                    Reply("Got it. I will remember: ${intent.fact}")
                } else {
                    Reply("Memory is turned off in Settings, so I did not save that.", isError = true)
                }
                record(text, reply)
            }
            Intent.Confirm, Intent.Cancel, Intent.ToAi -> routeToRoutineOrAi(text)
        }
    }

    /** Runs a Command Studio routine directly (used by the Studio "Test" button and trigger phrases). */
    suspend fun runRoutine(routine: RoutineEntity): Reply {
        val value = routine.actionValue
        return when (runCatching { RoutineAction.valueOf(routine.actionType) }.getOrNull()) {
            RoutineAction.FLASHLIGHT_ON -> fromResult(PhoneActions.setFlashlight(context, true))
            RoutineAction.FLASHLIGHT_OFF -> fromResult(PhoneActions.setFlashlight(context, false))
            RoutineAction.OPEN_APP -> fromResult(PhoneActions.openApp(context, value))
            RoutineAction.SPEAK -> Reply(value.ifBlank { "Routine ${routine.name} ran." })
            RoutineAction.ASK_AI -> when (val r = chat.send(value.ifBlank { routine.name })) {
                is AiResult.Ok -> Reply(r.text)
                is AiResult.Error -> Reply(r.message, isError = true)
            }
            null -> Reply("Unknown routine action: ${routine.actionType}", isError = true)
        }
    }

    private suspend fun routeToRoutineOrAi(text: String): Reply {
        val lower = text.lowercase()
        val routine = db.routineDao().enabled().firstOrNull {
            it.triggerPhrase.isNotBlank() && lower.contains(it.triggerPhrase.lowercase())
        }
        if (routine != null) return record(text, runRoutine(routine))

        return when (val r = chat.send(text)) {
            is AiResult.Ok -> Reply(r.text)
            is AiResult.Error -> Reply(r.message, isError = true)
        }
    }

    private suspend fun askConfirm(userText: String, what: String, run: () -> ActionResult): Reply {
        pending = Pending(what, run)
        return record(userText, Reply("I can $what. Say yes to confirm or no to cancel."))
    }

    private suspend fun setAlarm(intent: Intent.SetAlarm): Reply {
        val saved = db.alarmDao().insert(AlarmEntity(hour = intent.hour, minute = intent.minute, label = intent.label))
        val alarm = AlarmEntity(id = saved.toInt(), hour = intent.hour, minute = intent.minute, label = intent.label)
        val exact = alarms.schedule(alarm)
        val time = String.format("%02d:%02d", intent.hour, intent.minute)
        return Reply(
            if (exact) "Alarm set for $time."
            else "Alarm set for $time. Exact alarm permission is off, so it may ring a little late. Enable it in Settings."
        )
    }

    private fun fromResult(result: ActionResult): Reply = when (result) {
        is ActionResult.Success -> Reply(result.message)
        is ActionResult.Failure -> Reply(result.message, isError = true)
    }

    private suspend fun record(userText: String, reply: Reply): Reply {
        chat.appendLocal("user", userText)
        chat.appendLocal("assistant", reply.text)
        return reply
    }
}
