package com.shivam.os

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import com.shivam.os.ai.ChatRepository
import com.shivam.os.alarm.AlarmScheduler
import com.shivam.os.data.AppDatabase
import com.shivam.os.data.SettingsStore
import com.shivam.os.viewmodel.AssistantCore
import com.shivam.os.voice.Speaker

/** Application-scoped service container (manual dependency injection, no framework). */
class ShivamApp : Application() {

    val db: AppDatabase by lazy { AppDatabase.get(this) }
    val settings: SettingsStore by lazy { SettingsStore(this) }
    val chat: ChatRepository by lazy { ChatRepository(db, settings) }
    val alarms: AlarmScheduler by lazy { AlarmScheduler(this) }
    val assistant: AssistantCore by lazy { AssistantCore(this, db, chat, settings, alarms) }
    val speaker: Speaker by lazy { Speaker(this) }

    override fun onCreate() {
        super.onCreate()
        createChannels()
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        val alarmsChannel = NotificationChannel(
            CHANNEL_ALARMS, getString(R.string.alarm_channel_name), NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(R.string.alarm_channel_desc)
            enableVibration(true)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        val voiceChannel = NotificationChannel(
            CHANNEL_VOICE, getString(R.string.voice_channel_name), NotificationManager.IMPORTANCE_LOW
        ).apply { description = getString(R.string.voice_channel_desc) }
        nm.createNotificationChannels(listOf(alarmsChannel, voiceChannel))
    }

    companion object {
        const val CHANNEL_ALARMS = "chronexa_alarms"
        const val CHANNEL_VOICE = "jarvis_voice"
    }
}
