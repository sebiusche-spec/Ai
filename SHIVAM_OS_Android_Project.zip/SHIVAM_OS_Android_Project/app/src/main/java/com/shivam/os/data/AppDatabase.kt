package com.shivam.os.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MessageEntity::class, AlarmEntity::class, NoteEntity::class, MemoryEntity::class, RoutineEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun alarmDao(): AlarmDao
    abstract fun noteDao(): NoteDao
    abstract fun memoryDao(): MemoryDao
    abstract fun routineDao(): RoutineDao

    /** Privacy: wipes all locally stored conversations, alarms, notes, memories and routines. */
    suspend fun deleteAllUserData() {
        messageDao().clear()
        alarmDao().clear()
        noteDao().clear()
        memoryDao().clear()
        routineDao().clear()
    }

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "shivam_os.db"
            ).build().also { instance = it }
        }
    }
}
