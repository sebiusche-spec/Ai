package com.shivam.os.viewmodel

import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shivam.os.ShivamApp
import com.shivam.os.control.ActionResult
import com.shivam.os.control.PhoneActions
import com.shivam.os.control.SettingsPanel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class TimerState(val label: String = "", val remainingSeconds: Int = 0, val running: Boolean = false)

class ControlViewModel(private val app: ShivamApp) : ViewModel() {

    private val _lastResult = MutableStateFlow<ActionResult?>(null)
    val lastResult: StateFlow<ActionResult?> = _lastResult.asStateFlow()

    private val _flashlightOn = MutableStateFlow(false)
    val flashlightOn: StateFlow<Boolean> = _flashlightOn.asStateFlow()

    private val _installedApps = MutableStateFlow<List<String>>(emptyList())
    val installedApps: StateFlow<List<String>> = _installedApps.asStateFlow()

    private val _timer = MutableStateFlow(TimerState())
    val timer: StateFlow<TimerState> = _timer.asStateFlow()
    private var timerJob: Job? = null

    val hasFlashlight: Boolean get() = PhoneActions.hasFlashlight(app)

    init {
        viewModelScope.launch {
            _installedApps.value = withContext(Dispatchers.IO) {
                val pm = app.packageManager
                val intent = android.content.Intent(android.content.Intent.ACTION_MAIN)
                    .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
                    .map { it.loadLabel(pm).toString() }
                    .distinct().sorted()
            }
        }
    }

    /** Only called after the user confirms in the UI dialog. */
    fun confirmFlashlight(on: Boolean) {
        val result = PhoneActions.setFlashlight(app, on)
        _lastResult.value = result
        if (result is ActionResult.Success) _flashlightOn.value = on
    }

    fun confirmOpenApp(name: String) {
        _lastResult.value = PhoneActions.openApp(app, name)
    }

    fun openSettings(panel: SettingsPanel) {
        _lastResult.value = PhoneActions.openSettings(app, panel)
    }

    fun startTimer(seconds: Int, label: String) {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var remaining = seconds
            _timer.value = TimerState(label, remaining, running = true)
            while (remaining > 0) {
                delay(1_000)
                remaining--
                _timer.value = TimerState(label, remaining, running = remaining > 0)
            }
            // In-app timer only: it announces when the app is open. Background timers are not implemented.
            val s = app.settings
            app.speaker.speak("Timer finished: $label", s.ttsLanguage.first(), s.ttsSpeed.first(), s.ttsPitch.first())
        }
    }

    fun cancelTimer() {
        timerJob?.cancel()
        _timer.value = TimerState()
    }
}
