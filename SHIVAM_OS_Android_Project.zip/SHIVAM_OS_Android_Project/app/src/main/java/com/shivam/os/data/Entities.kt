package com.shivam.os.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,          // "user" | "assistant" | "system"
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val label: String,
    /** Bitmask: bit 0 = Sunday ... bit 6 = Saturday. 0 = one-shot. */
    val repeatDaysMask: Int = 0,
    val enabled: Boolean = true
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val createdAt: Long = System.currentTimeMillis()
)

/** Facts the user explicitly asked the assistant to remember ("remember that ..."). */
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fact: String,
    val createdAt: Long = System.currentTimeMillis()
)

/** Command Studio routine: when input contains triggerPhrase, run the action. */
@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val triggerPhrase: String,
    /** One of RoutineAction names, e.g. FLASHLIGHT_ON, OPEN_APP, SPEAK. */
    val actionType: String,
    val actionValue: String = "",
    val enabled: Boolean = true
)
